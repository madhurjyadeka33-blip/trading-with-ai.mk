/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { RetailDilemmaSection } from './components/RetailDilemmaSection';
import { HowItWorksSection } from './components/HowItWorksSection';
import { FeaturesBentoSection } from './components/FeaturesBentoSection';
import { SocialProofSection } from './components/SocialProofSection';
import { PricingSection } from './components/PricingSection';
import { FaqSection } from './components/FaqSection';
import { CtaSection } from './components/CtaSection';
import { Footer } from './components/Footer';
import { PerformanceLedgerView } from './components/PerformanceLedgerView';
import { LiveTerminalView } from './components/LiveTerminalView';
import { TrialModal } from './components/TrialModal';
import { SignInModal } from './components/SignInModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [trialModalOpen, setTrialModalOpen] = useState<boolean>(false);
  const [signInModalOpen, setSignInModalOpen] = useState<boolean>(false);
  const [selectedPlanForTrial, setSelectedPlanForTrial] = useState<'basic' | 'pro'>('pro');
  const [notification, setNotification] = useState<string | null>(null);
  const [mobileSimulatorMode, setMobileSimulatorMode] = useState<boolean>(false);

  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification(null);
    }, 4500);
  };

  const handleNavigate = (tab: string) => {
    setActiveTab(tab);
    if (tab !== 'performance' && tab !== 'terminal') {
      const el = document.getElementById(tab);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleStartTrial = (plan: 'basic' | 'pro' = 'pro') => {
    setSelectedPlanForTrial(plan);
    setTrialModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#0f131d] text-[#dfe2f1] flex flex-col font-sans selection:bg-[#38bdf8] selection:text-[#004965] relative">
      {/* Toast Notification */}
      {notification && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-2xl bg-[#1c1f2a] border border-[#38bdf8]/40 shadow-2xl text-xs font-mono text-[#8ed5ff] flex items-center gap-3 animate-in slide-in-from-bottom-5">
          <span className="material-symbols-outlined text-[20px] text-[#05e777]">check_circle</span>
          <span>{notification}</span>
        </div>
      )}

      {/* Floating Device Mode Toggle (Desktop / Mobile Preview) */}
      <aside aria-label="Screen mode switcher" className="fixed bottom-5 left-5 z-40 hidden sm:flex items-center gap-2 p-1.5 rounded-xl bg-[#171b26]/90 border border-[#262a35] backdrop-blur-md shadow-xl text-xs font-mono">
        <button
          onClick={() => setMobileSimulatorMode(false)}
          className={`px-2.5 py-1 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer ${
            !mobileSimulatorMode
              ? 'bg-[#38bdf8] text-[#00354a] font-bold'
              : 'text-[#87929a] hover:text-[#dfe2f1]'
          }`}
          title="Full responsive standard layout (Image 3)"
        >
          <span className="material-symbols-outlined text-[15px]">desktop_windows</span>
          <span>Desktop Standard</span>
        </button>
        <button
          onClick={() => setMobileSimulatorMode(true)}
          className={`px-2.5 py-1 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer ${
            mobileSimulatorMode
              ? 'bg-[#38bdf8] text-[#00354a] font-bold'
              : 'text-[#87929a] hover:text-[#dfe2f1]'
          }`}
          title="Mobile layout simulation (Image 1)"
        >
          <span className="material-symbols-outlined text-[15px]">smartphone</span>
          <span>Mobile View</span>
        </button>
      </aside>

      {/* Conditional Layout Container for Mobile Mode simulation if requested */}
      <div
        className={`w-full flex-1 flex flex-col transition-all duration-300 ${
          mobileSimulatorMode
            ? 'max-w-[440px] mx-auto my-6 border border-[#262a35] rounded-3xl overflow-hidden shadow-[0_0_50px_rgba(0,0,0,0.8)]'
            : ''
        }`}
      >
        {/* Top Header */}
        <Header
          activeTab={activeTab}
          onNavigate={handleNavigate}
          onOpenTrial={() => handleStartTrial('pro')}
          onOpenSignIn={() => setSignInModalOpen(true)}
        />

        {/* Main Content Area */}
        <main className="flex-1 pt-16">
          {activeTab === 'performance' ? (
            <PerformanceLedgerView
              onBackToOverview={() => handleNavigate('overview')}
              onStartTrial={() => handleStartTrial('pro')}
            />
          ) : activeTab === 'terminal' ? (
            <LiveTerminalView
              onBackToOverview={() => handleNavigate('overview')}
              onOpenTrial={() => handleStartTrial('pro')}
            />
          ) : (
            <>
              {/* 1. Hero Section */}
              <div id="overview">
                <HeroSection
                  onStartTrial={() => handleStartTrial('pro')}
                  onViewPerformance={() => handleNavigate('performance')}
                />
              </div>

              {/* 2. Retail Trader's Dilemma Section */}
              <RetailDilemmaSection
                onLearnMechanics={() => handleNavigate('how-it-works')}
              />

              {/* 3. How It Works Section */}
              <div id="how-it-works">
                <HowItWorksSection />
              </div>

              {/* 4. Features Bento Grid */}
              <div id="features">
                <FeaturesBentoSection
                  onOpenLedger={() => handleNavigate('performance')}
                  onOpenTerminal={() => handleNavigate('terminal')}
                />
              </div>

              {/* 5. Social Proof / Community Testimonials */}
              <SocialProofSection />

              {/* 6. Transparent Pricing */}
              <div id="pricing">
                <PricingSection
                  onSelectPlan={(plan) => handleStartTrial(plan)}
                />
              </div>

              {/* 7. Frequently Asked Questions */}
              <div id="faq">
                <FaqSection />
              </div>

              {/* 8. Ready to Upgrade CTA */}
              <CtaSection
                onSuccess={(email) =>
                  showToast(`7-Day Trial Provisioned for ${email}! Check your inbox.`)
                }
              />
            </>
          )}
        </main>

        {/* Footer */}
        <Footer onNavigate={handleNavigate} />
      </div>

      {/* Trial Activation Modal */}
      <TrialModal
        isOpen={trialModalOpen}
        onClose={() => setTrialModalOpen(false)}
        initialPlan={selectedPlanForTrial}
      />

      {/* Trader Sign In Modal */}
      <SignInModal
        isOpen={signInModalOpen}
        onClose={() => setSignInModalOpen(false)}
        onSuccess={(email) => showToast(`Welcome back, ${email}!`)}
      />
    </div>
  );
}
