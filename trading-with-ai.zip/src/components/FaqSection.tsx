import React, { useState } from 'react';
import { FAQ_DATA } from '../data/mockTradingData';

export const FaqSection: React.FC = () => {
  const [openIds, setOpenIds] = useState<string[]>(['faq-1']);

  const toggle = (id: string) => {
    setOpenIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  return (
    <section id="faq" className="w-full px-4 sm:px-6 lg:px-8 py-20 bg-[#0f131d]">
      <div className="max-w-4xl mx-auto flex flex-col gap-10">
        {/* Section Header */}
        <div className="flex flex-col items-center text-center space-y-2">
          <span className="font-mono text-[11px] uppercase tracking-wider text-[#38bdf8] font-semibold">
            SYSTEM KNOWLEDGE
          </span>
          <h2 className="text-2xl sm:text-4xl font-bold text-[#dfe2f1] tracking-tight">
            Frequently Asked Questions
          </h2>
          <p className="text-sm sm:text-base text-[#bdc8d1]">
            Clear answers regarding accuracy, mechanics, and asset coverage.
          </p>
        </div>

        {/* Accordions */}
        <div className="space-y-3">
          {FAQ_DATA.map((item) => {
            const isOpen = openIds.includes(item.id);
            return (
              <div
                key={item.id}
                className="rounded-2xl bg-[#171b26] border border-[#1c1f2a] hover:border-[#262a35] transition-colors overflow-hidden shadow-sm"
              >
                <button
                  type="button"
                  onClick={() => toggle(item.id)}
                  className="w-full p-5 sm:p-6 flex items-center justify-between text-left cursor-pointer group"
                  aria-expanded={isOpen}
                >
                  <span className="text-base sm:text-lg font-semibold text-[#dfe2f1] group-hover:text-[#8ed5ff] transition-colors pr-4">
                    {item.question}
                  </span>
                  <span
                    className={`material-symbols-outlined text-[#8ed5ff] text-[22px] transition-transform duration-300 shrink-0 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  >
                    expand_more
                  </span>
                </button>

                {isOpen && (
                  <div className="px-5 sm:px-6 pb-6 pt-1 text-sm sm:text-base text-[#bdc8d1] leading-relaxed border-t border-[#1c1f2a]/60 animate-in fade-in duration-200">
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
