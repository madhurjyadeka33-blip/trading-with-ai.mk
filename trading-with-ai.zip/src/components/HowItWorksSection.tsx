import React, { useState } from 'react';

export const HowItWorksSection: React.FC = () => {
  const [selectedWatchlists, setSelectedWatchlists] = useState<string[]>([
    'NVDA',
    'AAPL',
    'TSLA',
    'EUR/USD',
  ]);

  const [activeSignalIndex, setActiveSignalIndex] = useState<number>(0);

  const signalSamples = [
    { dir: 'BULLISH', conf: '91% CONF', color: 'text-[#05e777]', bg: 'bg-[#05e777]/20', border: 'border-[#05e777]/30' },
    { dir: 'BEARISH', conf: '88% CONF', color: 'text-[#ffb4ab]', bg: 'bg-[#ffb4ab]/20', border: 'border-[#ffb4ab]/30' },
    { dir: 'BREAKOUT', conf: '94% CONF', color: 'text-[#38bdf8]', bg: 'bg-[#38bdf8]/20', border: 'border-[#38bdf8]/30' },
  ];

  const currentSample = signalSamples[activeSignalIndex];

  const toggleWatchlist = (sym: string) => {
    setSelectedWatchlists((prev) =>
      prev.includes(sym) ? prev.filter((s) => s !== sym) : [...prev, sym]
    );
  };

  return (
    <section id="how-it-works" className="w-full px-4 sm:px-6 lg:px-8 py-20 bg-[#0f131d]">
      <div className="max-w-7xl mx-auto flex flex-col gap-12">
        {/* Section Header */}
        <div className="flex flex-col items-center text-center max-w-2xl mx-auto space-y-2">
          <div className="inline-block px-3.5 py-1 rounded-full bg-[#262a35] border border-[#3e484f]/60 text-[#8ed5ff] font-mono text-[11px] font-semibold tracking-wider uppercase">
            Simple 3-Step Process
          </div>
          <h2 className="text-2xl sm:text-4xl font-bold text-[#dfe2f1] tracking-tight">
            Disciplined execution in three steps
          </h2>
          <p className="text-sm sm:text-base text-[#bdc8d1]">
            Streamline your decision tree without abandoning manual discretion.
          </p>
        </div>

        {/* 3 Step Cards */}
        <div className="space-y-4 max-w-5xl mx-auto w-full">
          {/* Step 1 */}
          <div className="p-6 rounded-2xl bg-[#1c1f2a] border border-[#262a35] flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-md hover:border-[#38bdf8]/40 transition-colors">
            <div className="space-y-2 max-w-xl">
              <div className="flex items-center gap-3">
                <span className="font-mono text-[14px] font-bold text-[#38bdf8] px-2.5 py-1 rounded-md bg-[#38bdf8]/15 border border-[#38bdf8]/30">
                  STEP 01
                </span>
                <h3 className="text-lg sm:text-xl text-[#dfe2f1] font-semibold">
                  Connect your watchlists
                </h3>
              </div>
              <p className="text-sm text-[#bdc8d1] leading-relaxed">
                Connect your watchlists. Select the assets and markets you trade most frequently to start receiving tailored data.
              </p>
            </div>

            {/* Interactive Asset Selector Pills */}
            <div className="flex flex-wrap gap-2 p-2 rounded-xl bg-[#0a0e18] border border-[#1c1f2a]">
              {['AAPL', 'NVDA', 'TSLA', 'EUR/USD', 'SPY', 'QQQ'].map((sym) => {
                const isSelected = selectedWatchlists.includes(sym);
                return (
                  <button
                    key={sym}
                    type="button"
                    onClick={() => toggleWatchlist(sym)}
                    className={`px-3 py-1.5 rounded-lg font-mono text-[12px] font-medium transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#38bdf8]/20 text-[#8ed5ff] border border-[#38bdf8]/50 shadow-sm'
                        : 'bg-[#262a35] text-[#bdc8d1] hover:text-[#dfe2f1]'
                    }`}
                  >
                    {sym}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 2 */}
          <div className="p-6 rounded-2xl bg-[#1c1f2a] border border-[#262a35] flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-md hover:border-[#38bdf8]/40 transition-colors">
            <div className="space-y-2 max-w-xl">
              <div className="flex items-center gap-3">
                <span className="font-mono text-[14px] font-bold text-[#38bdf8] px-2.5 py-1 rounded-md bg-[#38bdf8]/15 border border-[#38bdf8]/30">
                  STEP 02
                </span>
                <h3 className="text-lg sm:text-xl text-[#dfe2f1] font-semibold">
                  Receive direction signals
                </h3>
              </div>
              <p className="text-sm text-[#bdc8d1] leading-relaxed">
                Receive direction signals. The AI processes millions of data points to identify high-probability up or down movements.
              </p>
            </div>

            {/* AI Neural processing badge with click-to-preview */}
            <div
              onClick={() => setActiveSignalIndex((prev) => (prev + 1) % signalSamples.length)}
              className="p-3 rounded-xl bg-[#0a0e18] border border-[#1c1f2a] flex items-center gap-3 min-w-[210px] justify-between cursor-pointer hover:border-[#8ed5ff]/40 transition-all"
              title="Click to test another simulated prediction"
            >
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#38bdf8] text-[20px] animate-pulse">
                  neurology
                </span>
                <span className={`font-mono text-[12px] font-bold ${currentSample.color}`}>
                  {currentSample.dir}
                </span>
              </div>
              <span className={`font-mono text-[11px] px-2.5 py-1 rounded ${currentSample.bg} ${currentSample.border} border font-bold text-[#dfe2f1]`}>
                {currentSample.conf}
              </span>
            </div>
          </div>

          {/* Step 3 */}
          <div className="p-6 rounded-2xl bg-[#1c1f2a] border border-[#262a35] flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-md hover:border-[#38bdf8]/40 transition-colors">
            <div className="space-y-2 max-w-xl">
              <div className="flex items-center gap-3">
                <span className="font-mono text-[14px] font-bold text-[#38bdf8] px-2.5 py-1 rounded-md bg-[#38bdf8]/15 border border-[#38bdf8]/30">
                  STEP 03
                </span>
                <h3 className="text-lg sm:text-xl text-[#dfe2f1] font-semibold">
                  Execute with confidence
                </h3>
              </div>
              <p className="text-sm text-[#bdc8d1] leading-relaxed">
                Execute with confidence. Use the signals as a secondary confirmation to stay disciplined and stick to your trading plan.
              </p>
            </div>

            {/* Order Confirmation Chip */}
            <div className="p-3 rounded-xl bg-[#0a0e18] border border-[#1c1f2a] flex items-center gap-4 font-mono text-[12px]">
              <div className="flex items-center gap-1.5 text-[#05e777]">
                <span className="material-symbols-outlined text-[18px]">check_circle</span>
                <span className="font-semibold">CONFIRMED</span>
              </div>
              <span className="text-[#87929a] font-medium border-l border-[#262a35] pl-3">
                R:R 1:3.2
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
