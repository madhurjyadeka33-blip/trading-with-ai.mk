import React, { useState } from 'react';

interface SignInModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (email: string) => void;
}

export const SignInModal: React.FC<SignInModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    onSuccess(email || 'trader@propfirm.com');
    onClose();
  };

  const handleDemoLogin = () => {
    onSuccess('demo.trader@alphadesk.com');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md rounded-3xl bg-[#171b26] border border-[#262a35] p-6 sm:p-8 shadow-2xl text-left">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-[#87929a] hover:text-[#dfe2f1] transition-colors cursor-pointer"
        >
          <span className="material-symbols-outlined text-[22px]">close</span>
        </button>

        <div className="space-y-6">
          <div>
            <div className="w-9 h-9 rounded-xl bg-[#262a35] border border-[#3e484f]/40 flex items-center justify-center text-[#8ed5ff] mb-3">
              <span className="material-symbols-outlined text-[20px]">lock</span>
            </div>
            <h2 className="text-2xl font-bold text-[#dfe2f1] tracking-tight">
              Trader Portal Access
            </h2>
            <p className="text-xs text-[#bdc8d1] mt-1">
              Sign in to your Trading with AI subscriber terminal.
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-3.5">
            <div className="space-y-1">
              <label className="text-xs font-mono text-[#87929a] uppercase">Registered Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@fund.com"
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0a0e18] border border-[#262a35] text-sm text-[#dfe2f1] font-mono focus:outline-none focus:border-[#38bdf8]"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-mono text-[#87929a] uppercase">Passkey / Password</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0a0e18] border border-[#262a35] text-sm text-[#dfe2f1] font-mono focus:outline-none focus:border-[#38bdf8]"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-[#38bdf8] hover:bg-[#8ed5ff] text-[#00354a] font-semibold text-sm transition-all cursor-pointer shadow-md"
            >
              Sign In to Terminal
            </button>
          </form>

          <div className="relative flex items-center justify-center">
            <div className="border-t border-[#1c1f2a] w-full" />
            <span className="bg-[#171b26] px-3 font-mono text-[10px] text-[#87929a] uppercase absolute">
              Quick Test
            </span>
          </div>

          <button
            type="button"
            onClick={handleDemoLogin}
            className="w-full py-2.5 rounded-xl bg-[#262a35] hover:bg-[#313540] border border-[#3e484f]/60 text-[#8ed5ff] font-mono text-xs font-semibold transition-colors cursor-pointer flex items-center justify-center gap-2"
          >
            <span className="material-symbols-outlined text-[16px]">account_circle</span>
            <span>Instant Access as Demo Trader</span>
          </button>
        </div>
      </div>
    </div>
  );
};
