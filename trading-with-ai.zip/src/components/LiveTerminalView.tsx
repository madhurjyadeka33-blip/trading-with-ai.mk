import React, { useState } from 'react';
import { TICKERS_DATA } from '../data/mockTradingData';

interface LiveTerminalViewProps {
  onBackToOverview: () => void;
  onOpenTrial: () => void;
}

export const LiveTerminalView: React.FC<LiveTerminalViewProps> = ({
  onBackToOverview,
  onOpenTrial,
}) => {
  const [selectedSymbol, setSelectedSymbol] = useState<string>('SPY');
  const [accountBalance, setAccountBalance] = useState<number>(25000);
  const [riskPercent, setRiskPercent] = useState<number>(1.0);
  const [executionStatus, setExecutionStatus] = useState<string | null>(null);

  const activeTicker = TICKERS_DATA[selectedSymbol] || TICKERS_DATA['SPY'];

  // Calculations for Risk Co-Pilot
  const maxRiskDollars = (accountBalance * (riskPercent / 100));
  const perShareRisk = Math.abs(activeTicker.signal.entry - activeTicker.signal.stop);
  const recommendedShares = perShareRisk > 0 ? Math.floor(maxRiskDollars / perShareRisk) : 0;
  const targetProfitDollars = recommendedShares * Math.abs(activeTicker.signal.target - activeTicker.signal.entry);

  const handleSimulateExecution = () => {
    setExecutionStatus('VALIDATING_NEURAL_VECTOR');
    setTimeout(() => {
      setExecutionStatus('CONFIRMED_R_R');
      setTimeout(() => {
        setExecutionStatus('EXECUTED');
      }, 900);
    }, 800);
  };

  return (
    <div className="w-full min-h-screen bg-[#0f131d] px-4 sm:px-6 lg:px-8 py-10">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Navigation Breadcrumb / Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-[#1c1f2a]">
          <div className="space-y-1">
            <button
              onClick={onBackToOverview}
              className="inline-flex items-center gap-1.5 text-xs font-mono text-[#8ed5ff] hover:text-[#dfe2f1] transition-colors cursor-pointer mb-1"
            >
              <span className="material-symbols-outlined text-[16px]">arrow_back</span>
              <span>Back to Overview</span>
            </button>
            <h1 className="text-2xl sm:text-3xl font-bold text-[#dfe2f1] tracking-tight">
              AI Neural Execution Cockpit
            </h1>
            <p className="text-xs sm:text-sm text-[#bdc8d1]">
              Sub-second algorithmic signal validation, live order book matrix, and Risk Co-Pilot capital shield.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-[#00622e]/20 text-[#05e777] font-mono text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-[#05e777] animate-pulse" />
              ENGINE CLUSTER: ACTIVE
            </span>
            <button
              onClick={onOpenTrial}
              className="px-4 py-2 rounded-xl bg-[#38bdf8] text-[#00354a] font-semibold text-xs sm:text-sm hover:bg-[#8ed5ff] transition-all cursor-pointer shadow-md"
            >
              Start 7-Day Trial
            </button>
          </div>
        </div>

        {/* Cockpit Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Watchlist & Signal Inspector (4 cols) */}
          <div className="lg:col-span-4 space-y-4">
            <div className="p-4 rounded-2xl bg-[#171b26] border border-[#1c1f2a] space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs uppercase tracking-wider text-[#87929a] font-semibold">
                  Monitored Assets
                </span>
                <span className="font-mono text-[11px] text-[#38bdf8]">5 Active Vectors</span>
              </div>

              <div className="space-y-2">
                {Object.keys(TICKERS_DATA).map((sym) => {
                  const data = TICKERS_DATA[sym];
                  const isSelected = selectedSymbol === sym;
                  const isBull = data.signal.direction === 'BULLISH';

                  return (
                    <div
                      key={sym}
                      onClick={() => setSelectedSymbol(sym)}
                      className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                        isSelected
                          ? 'bg-[#1c1f2a] border-[#38bdf8] shadow-md'
                          : 'bg-[#0a0e18] border-[#1c1f2a] hover:border-[#3e484f]'
                      }`}
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-sm text-[#dfe2f1]">{data.symbol}</span>
                          <span className="text-[10px] text-[#87929a]">{data.name}</span>
                        </div>
                        <span className="font-mono text-xs text-[#bdc8d1]">
                          ${data.price.toLocaleString()}
                        </span>
                      </div>

                      <div className="text-right">
                        <span
                          className={`inline-block px-2 py-0.5 rounded font-mono text-[10px] font-bold ${
                            isBull
                              ? 'bg-[#05e777]/20 text-[#05e777]'
                              : 'bg-[#ffb4ab]/20 text-[#ffb4ab]'
                          }`}
                        >
                          {data.signal.type.split(' ')[0]} {data.signal.confidence}%
                        </span>
                        <div className="text-[10px] font-mono text-[#87929a] mt-0.5">
                          R:R {data.signal.riskReward}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Live Order Book Depth Simulator */}
            <div className="p-4 rounded-2xl bg-[#171b26] border border-[#1c1f2a] space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-[#1c1f2a]">
                <span className="text-[#87929a] uppercase text-[11px]">Level 2 Order Book</span>
                <span className="text-[#05e777] text-[10px]">Spread: $0.02</span>
              </div>

              {/* Asks (Sell Orders) */}
              <div className="space-y-1 text-[11px]">
                <div className="flex justify-between text-[#ffb4ab]">
                  <span>${(activeTicker.price + 0.15).toFixed(2)}</span>
                  <span>14,200</span>
                </div>
                <div className="flex justify-between text-[#ffb4ab]">
                  <span>${(activeTicker.price + 0.08).toFixed(2)}</span>
                  <span>8,400</span>
                </div>
                <div className="flex justify-between text-[#ffb4ab] font-bold">
                  <span>${(activeTicker.price + 0.02).toFixed(2)}</span>
                  <span>32,900 [WALL]</span>
                </div>
              </div>

              {/* Mid Price */}
              <div className="py-1 px-2 rounded bg-[#0a0e18] flex justify-between font-bold text-[#dfe2f1] border-y border-[#262a35]">
                <span>MARK: ${activeTicker.price.toFixed(2)}</span>
                <span className="text-[#38bdf8]">LSTM BIAS ↑</span>
              </div>

              {/* Bids (Buy Orders) */}
              <div className="space-y-1 text-[11px]">
                <div className="flex justify-between text-[#05e777] font-bold">
                  <span>${(activeTicker.price - 0.02).toFixed(2)}</span>
                  <span>41,500 [WALL]</span>
                </div>
                <div className="flex justify-between text-[#05e777]">
                  <span>${(activeTicker.price - 0.07).toFixed(2)}</span>
                  <span>12,800</span>
                </div>
                <div className="flex justify-between text-[#05e777]">
                  <span>${(activeTicker.price - 0.12).toFixed(2)}</span>
                  <span>9,100</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Risk Co-Pilot & Execution Ticket (8 cols) */}
          <div className="lg:col-span-8 space-y-6">
            {/* Active Vector Detail Box */}
            <div className="p-6 rounded-2xl bg-[#171b26] border border-[#1c1f2a] space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <span className="font-mono text-xs text-[#87929a] uppercase">Active Neural Signal</span>
                  <h2 className="text-2xl font-bold text-[#dfe2f1] flex items-center gap-2">
                    <span>{activeTicker.symbol}</span>
                    <span className="text-[#05e777] text-lg font-mono">
                      {activeTicker.signal.type}
                    </span>
                  </h2>
                </div>
                <div className="text-right">
                  <span className="px-3 py-1 rounded bg-[#05e777]/20 border border-[#05e777]/30 text-[#05e777] font-mono font-bold text-xs">
                    +{activeTicker.signal.confidence}% Model Confidence
                  </span>
                  <div className="text-xs font-mono text-[#87929a] mt-1">
                    Model: {activeTicker.chart.model}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3 pt-2">
                <div className="p-3 rounded-xl bg-[#0a0e18] border border-[#1c1f2a]">
                  <span className="text-[10px] font-mono text-[#87929a] uppercase">Entry Level</span>
                  <div className="text-lg font-mono font-bold text-[#dfe2f1]">
                    ${activeTicker.signal.entry.toLocaleString()}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-[#0a0e18] border border-[#1c1f2a]">
                  <span className="text-[10px] font-mono text-[#87929a] uppercase">Target Price</span>
                  <div className="text-lg font-mono font-bold text-[#05e777]">
                    ${activeTicker.signal.target.toLocaleString()}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-[#0a0e18] border border-[#1c1f2a]">
                  <span className="text-[10px] font-mono text-[#87929a] uppercase">Trailing Stop</span>
                  <div className="text-lg font-mono font-bold text-[#ffb4ab]">
                    ${activeTicker.signal.stop.toLocaleString()}
                  </div>
                </div>
              </div>
            </div>

            {/* Interactive Risk Co-Pilot Calculator */}
            <div className="p-6 rounded-2xl bg-[#1c1f2a] border border-[#262a35] space-y-6">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#ff938d]/20 border border-[#ff938d]/30 flex items-center justify-center text-[#ffbcb8]">
                  <span className="material-symbols-outlined text-[18px]">shield</span>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-[#dfe2f1]">
                    Risk Co-Pilot Sizing Engine
                  </h3>
                  <p className="text-xs text-[#bdc8d1]">
                    Automates strict capital protection math to eradicate catastrophic drawdown risk.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Account Size */}
                <div className="space-y-1.5">
                  <label className="text-xs font-mono text-[#87929a] uppercase">
                    Portfolio Capital ($)
                  </label>
                  <input
                    type="number"
                    value={accountBalance}
                    onChange={(e) => setAccountBalance(Number(e.target.value) || 1000)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0a0e18] border border-[#262a35] font-mono text-sm text-[#dfe2f1] focus:outline-none focus:border-[#38bdf8]"
                  />
                </div>

                {/* Risk Tolerance */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-[#87929a] uppercase">Max Trade Risk (%)</span>
                    <span className="text-[#38bdf8] font-bold">{riskPercent}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.25"
                    max="3.0"
                    step="0.25"
                    value={riskPercent}
                    onChange={(e) => setRiskPercent(Number(e.target.value))}
                    className="w-full h-2 rounded-lg bg-[#0a0e18] accent-[#38bdf8] cursor-pointer"
                  />
                </div>
              </div>

              {/* Sizing Outputs */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-[#0a0e18] border border-[#1c1f2a] font-mono text-xs">
                <div>
                  <span className="text-[#87929a] block">Max Risk Budget</span>
                  <span className="text-base font-bold text-[#ffb4ab]">
                    ${maxRiskDollars.toFixed(0)}
                  </span>
                </div>
                <div>
                  <span className="text-[#87929a] block">Recommended Units</span>
                  <span className="text-base font-bold text-[#8ed5ff]">
                    {recommendedShares} shares
                  </span>
                </div>
                <div>
                  <span className="text-[#87929a] block">Potential Profit</span>
                  <span className="text-base font-bold text-[#05e777]">
                    +${targetProfitDollars.toFixed(0)}
                  </span>
                </div>
                <div>
                  <span className="text-[#87929a] block">Net R:R Ratio</span>
                  <span className="text-base font-bold text-[#dfe2f1]">
                    {activeTicker.signal.riskReward}
                  </span>
                </div>
              </div>

              {/* Execution Feedback / Simulated Action */}
              <div className="space-y-3 pt-2">
                {executionStatus === 'EXECUTED' ? (
                  <div className="p-4 rounded-xl bg-[#00622e]/30 border border-[#05e777]/50 text-[#7dffa2] flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="material-symbols-outlined text-[22px]">verified</span>
                      <span className="font-mono text-sm font-semibold">
                        Trade Order Executed with AI Confirmation ({recommendedShares} Units of {activeTicker.symbol})
                      </span>
                    </div>
                    <button
                      onClick={() => setExecutionStatus(null)}
                      className="text-xs underline text-[#dfe2f1] cursor-pointer"
                    >
                      Reset
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={handleSimulateExecution}
                    disabled={executionStatus !== null}
                    className="w-full py-3.5 rounded-xl bg-[#38bdf8] hover:bg-[#8ed5ff] text-[#00354a] font-semibold text-sm transition-all cursor-pointer shadow-lg shadow-[#38bdf8]/20 flex items-center justify-center gap-2 active:scale-[0.99] disabled:opacity-50"
                  >
                    <span className="material-symbols-outlined text-[18px]">
                      {executionStatus ? 'hourglass_top' : 'task_alt'}
                    </span>
                    <span>
                      {executionStatus === 'VALIDATING_NEURAL_VECTOR' && 'Scanning Order Book & Latency Queues...'}
                      {executionStatus === 'CONFIRMED_R_R' && 'AI Confirmation Approved: Executing Order...'}
                      {!executionStatus && `Simulate AI Trade Entry (${recommendedShares} Units @ $${activeTicker.signal.entry})`}
                    </span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
