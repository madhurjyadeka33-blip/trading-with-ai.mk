import React, { useState } from 'react';

interface TrialModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPlan?: 'basic' | 'pro';
}

export const TrialModal: React.FC<TrialModalProps> = ({
  isOpen,
  onClose,
  initialPlan = 'pro',
}) => {
  const [selectedPlan, setSelectedPlan] = useState<'basic' | 'pro'>(initialPlan);
  const [email, setEmail] = useState('');
  const [platform, setPlatform] = useState('TradingView');
  const [completed, setCompleted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCompleted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl bg-[#171b26] border border-[#262a35] p-6 sm:p-8 shadow-2xl text-left">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-[#87929a] hover:text-[#dfe2f1] transition-colors cursor-pointer"
        >
          <span className="material-symbols-outlined text-[22px]">close</span>
        </button>

        {!completed ? (
          <div className="space-y-6">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#38bdf8]/15 border border-[#38bdf8]/30 text-[#8ed5ff] font-mono text-[11px] font-bold uppercase tracking-wider mb-2">
                <span className="material-symbols-outlined text-[14px]">bolt</span>
                Zero Credit Card Required
              </div>
              <h2 className="text-2xl font-bold text-[#dfe2f1] tracking-tight">
                Start Your 7-Day Free Trial
              </h2>
              <p className="text-xs sm:text-sm text-[#bdc8d1] mt-1">
                Gain immediate sub-second access to institutional LSTM breakout models.
              </p>
            </div>

            {/* Plan Selector */}
            <div className="grid grid-cols-2 gap-3 font-mono text-xs">
              <button
                type="button"
                onClick={() => setSelectedPlan('basic')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedPlan === 'basic'
                    ? 'bg-[#1c1f2a] border-[#38bdf8] text-[#dfe2f1]'
                    : 'bg-[#0a0e18] border-[#1c1f2a] text-[#87929a] hover:border-[#3e484f]'
                }`}
              >
                <div className="font-bold text-sm">Basic Plan</div>
                <div className="text-lg font-bold text-[#dfe2f1] my-1">$50/mo</div>
                <div className="text-[11px] text-[#87929a]">Daily signals & dashboard</div>
              </button>

              <button
                type="button"
                onClick={() => setSelectedPlan('pro')}
                className={`p-3.5 rounded-xl border text-left transition-all relative cursor-pointer ${
                  selectedPlan === 'pro'
                    ? 'bg-[#1c1f2a] border-[#38bdf8] text-[#dfe2f1]'
                    : 'bg-[#0a0e18] border-[#1c1f2a] text-[#87929a] hover:border-[#3e484f]'
                }`}
              >
                <span className="absolute top-2 right-2 px-1.5 py-0.5 rounded bg-[#38bdf8] text-[#004965] text-[9px] font-bold">
                  POPULAR
                </span>
                <div className="font-bold text-sm text-[#8ed5ff]">Pro Plan</div>
                <div className="text-lg font-bold text-[#dfe2f1] my-1">$200/mo</div>
                <div className="text-[11px] text-[#87929a]">Real-time push & Risk Co-Pilot</div>
              </button>
            </div>

            {/* Trial Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-mono text-[#87929a] uppercase">Work or Trading Email</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="trader@hedgefund.com"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#0a0e18] border border-[#262a35] text-sm text-[#dfe2f1] placeholder:text-[#87929a] font-mono focus:outline-none focus:border-[#38bdf8]"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-mono text-[#87929a] uppercase">Primary Trading Platform</label>
                <select
                  value={platform}
                  onChange={(e) => setPlatform(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#0a0e18] border border-[#262a35] text-sm text-[#dfe2f1] font-mono focus:outline-none focus:border-[#38bdf8]"
                >
                  <option value="TradingView">TradingView (Webhook Alerts)</option>
                  <option value="Interactive Brokers">Interactive Brokers (TWS / API)</option>
                  <option value="ThinkOrSwim">Charles Schwab / ThinkOrSwim</option>
                  <option value="Binance">Binance / Crypto API</option>
                  <option value="MetaTrader">MetaTrader 4 / 5</option>
                  <option value="Webull">Webull Desktop</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-[#38bdf8] hover:bg-[#8ed5ff] text-[#00354a] font-semibold text-sm shadow-lg shadow-[#38bdf8]/20 transition-all cursor-pointer active:scale-[0.98] flex items-center justify-center gap-2"
              >
                <span className="material-symbols-outlined text-[18px]">bolt</span>
                <span>Activate Free Instant Access</span>
              </button>

              <p className="text-[11px] text-center text-[#87929a] font-mono">
                No credit card needed • Cancel in 1-click anytime in account settings.
              </p>
            </form>
          </div>
        ) : (
          /* Confirmation State */
          <div className="space-y-6 text-center py-4">
            <div className="w-14 h-14 rounded-2xl bg-[#00622e]/30 border border-[#05e777]/50 text-[#05e777] flex items-center justify-center mx-auto">
              <span className="material-symbols-outlined text-[32px]">check_circle</span>
            </div>

            <div className="space-y-2">
              <h3 className="text-2xl font-bold text-[#dfe2f1]">Trial Activated!</h3>
              <p className="text-xs sm:text-sm text-[#bdc8d1]">
                We have enabled your 7-day Pro access for <span className="text-[#8ed5ff] font-mono">{email || 'your account'}</span>.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#0a0e18] border border-[#1c1f2a] text-left font-mono text-xs space-y-2">
              <div className="flex justify-between text-[#87929a]">
                <span>FEED TOKEN:</span>
                <span className="text-[#05e777]">LIVE-ALPHA-8921-OK</span>
              </div>
              <div className="flex justify-between text-[#87929a]">
                <span>DESTINATION:</span>
                <span className="text-[#dfe2f1]">{platform}</span>
              </div>
              <div className="flex justify-between text-[#87929a]">
                <span>EXPIRES:</span>
                <span className="text-[#dfe2f1]">7 Days from Today</span>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="w-full py-3 rounded-xl bg-[#262a35] hover:bg-[#313540] text-[#dfe2f1] font-semibold text-xs transition-colors cursor-pointer"
            >
              Enter Live Platform
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
