import React from 'react';

interface RetailDilemmaSectionProps {
  onLearnMechanics: () => void;
}

export const RetailDilemmaSection: React.FC<RetailDilemmaSectionProps> = ({
  onLearnMechanics,
}) => {
  const dilemmas = [
    {
      badge: 'POOR TIMING & LATENCY',
      quote: '"I feel like the market moves the moment I enter a trade."',
      factor: 'Millisecond HFT queues',
      penalty: 'Retail order latency penalty',
      icon: 'schedule',
    },
    {
      badge: 'EMOTIONAL SECOND-GUESSING',
      quote: '"I have a strategy, but I always second-guess myself when things get volatile."',
      factor: 'Fear & greed impulse',
      penalty: 'Dopamine-driven exits',
      icon: 'psychology',
    },
    {
      badge: 'INFORMATION ASYMMETRY',
      quote: '"I know the data is out there, but I don\'t have the tools to process it in real-time."',
      factor: 'Multi-exchange book tape',
      penalty: 'Fragmented dark pools',
      icon: 'data_loss_prevention',
    },
  ];

  return (
    <section className="w-full px-4 sm:px-6 lg:px-8 py-20 bg-[#0a0e18] border-y border-[#1c1f2a]">
      <div className="max-w-7xl mx-auto flex flex-col gap-12">
        {/* Section Header */}
        <div className="flex flex-col items-center text-center max-w-2xl mx-auto space-y-2">
          <span className="font-mono text-[11px] sm:text-[12px] uppercase tracking-widest text-[#ffb4ab] font-semibold">
            The Market Inequity
          </span>
          <h2 className="text-2xl sm:text-4xl font-bold text-[#dfe2f1] tracking-tight">
            The Retail Trader's Dilemma
          </h2>
          <p className="text-sm sm:text-base text-[#bdc8d1] max-w-xl">
            Why trading solo feels like an uphill battle against institutional algorithms.
          </p>
        </div>

        {/* 3 Quotation Challenge Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {dilemmas.map((item, idx) => (
            <div
              key={idx}
              className="flex flex-col justify-between p-6 rounded-2xl bg-[#171b26] border border-[#1c1f2a] hover:border-[#3e484f] transition-all shadow-sm group"
            >
              <div className="space-y-4">
                <span className="inline-block px-2.5 py-1 rounded bg-[#93000a]/25 border border-[#ffb4ab]/30 text-[#ffdad7] font-mono text-[11px] uppercase tracking-wider font-semibold">
                  {item.badge}
                </span>
                <p className="text-base text-[#dfe2f1] italic leading-relaxed">
                  {item.quote}
                </p>
              </div>

              <div className="pt-6 mt-6 border-t border-[#1c1f2a] flex items-center justify-between text-[#87929a] font-mono text-[11px]">
                <span>Factor: {item.factor}</span>
                <span className="text-[#ffb4ab] flex items-center gap-1">
                  <span className="material-symbols-outlined text-[15px]">{item.icon}</span>
                  {item.penalty}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Contrasting Solution Banner */}
        <div className="w-full p-5 sm:p-6 rounded-2xl bg-[#1c1f2a] border border-[#262a35] flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left shadow-lg">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-[#38bdf8]/15 border border-[#38bdf8]/30 flex items-center justify-center text-[#8ed5ff] shrink-0">
              <span className="material-symbols-outlined text-[22px]">balance</span>
            </div>
            <span className="text-base sm:text-lg font-semibold text-[#8ed5ff]">
              You don't need a Wall Street budget. You just need a data-backed co-pilot.
            </span>
          </div>

          <button
            type="button"
            onClick={onLearnMechanics}
            className="px-4 py-2 rounded-xl bg-[#262a35] hover:bg-[#313540] border border-[#3e484f]/60 text-[#8ed5ff] font-mono text-[13px] font-medium transition-all shrink-0 cursor-pointer flex items-center gap-1.5"
          >
            <span>Learn the Mechanics</span>
            <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
          </button>
        </div>
      </div>
    </section>
  );
};
