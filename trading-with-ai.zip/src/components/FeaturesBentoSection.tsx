import React from 'react';

interface FeaturesBentoSectionProps {
  onOpenLedger: () => void;
  onOpenTerminal: () => void;
}

export const FeaturesBentoSection: React.FC<FeaturesBentoSectionProps> = ({
  onOpenLedger,
  onOpenTerminal,
}) => {
  return (
    <section id="features" className="w-full px-4 sm:px-6 lg:px-8 py-20 bg-[#0a0e18] border-y border-[#1c1f2a]">
      <div className="max-w-7xl mx-auto flex flex-col gap-12">
        {/* Section Title */}
        <div className="flex flex-col items-center text-center max-w-2xl mx-auto space-y-2">
          <span className="font-mono text-[11px] uppercase tracking-wider text-[#38bdf8] font-semibold">
            ADVANCED TOOLSET
          </span>
          <h2 className="text-2xl sm:text-4xl font-bold text-[#dfe2f1] tracking-tight">
            Built for execution, not speculation
          </h2>
          <p className="text-sm sm:text-base text-[#bdc8d1]">
            A comprehensive toolkit designed specifically for personal capital managers.
          </p>
        </div>

        {/* 2x2 Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto w-full">
          {/* Feature 1 */}
          <div className="p-6 sm:p-7 rounded-2xl bg-[#171b26] border border-[#1c1f2a] flex flex-col justify-between space-y-6 shadow-sm hover:border-[#38bdf8]/40 transition-all group">
            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <div className="w-12 h-12 rounded-xl bg-[#38bdf8]/15 border border-[#38bdf8]/30 flex items-center justify-center text-[#8ed5ff]">
                  <span className="material-symbols-outlined text-[24px]">trending_up</span>
                </div>
                <span className="px-2.5 py-1 rounded bg-[#262a35] text-[#87929a] font-mono text-[11px]">
                  Pattern recognition
                </span>
              </div>
              <div>
                <h3 className="text-lg sm:text-xl text-[#dfe2f1] font-semibold">
                  High-Accuracy Predictions
                </h3>
                <p className="text-sm text-[#bdc8d1] mt-2 leading-relaxed">
                  Our models analyze historical patterns and real-time volume to predict the next market move with precision.
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-[#1c1f2a] flex items-center justify-between text-[#87929a] font-mono text-[12px]">
              <span>Model Health:</span>
              <span className="text-[#05e777] font-semibold">99.4% Uptime</span>
            </div>
          </div>

          {/* Feature 2 */}
          <div className="p-6 sm:p-7 rounded-2xl bg-[#171b26] border border-[#1c1f2a] flex flex-col justify-between space-y-6 shadow-sm hover:border-[#38bdf8]/40 transition-all group">
            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <div className="w-12 h-12 rounded-xl bg-[#38bdf8]/15 border border-[#38bdf8]/30 flex items-center justify-center text-[#8ed5ff]">
                  <span className="material-symbols-outlined text-[24px]">notifications_active</span>
                </div>
                <span className="px-2.5 py-1 rounded bg-[#262a35] text-[#87929a] font-mono text-[11px]">
                  Latency SLA
                </span>
              </div>
              <div>
                <h3 className="text-lg sm:text-xl text-[#dfe2f1] font-semibold">
                  Real-Time Alerts
                </h3>
                <p className="text-sm text-[#bdc8d1] mt-2 leading-relaxed">
                  Get instant push notifications the moment the AI detects a significant shift in market direction.
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-[#1c1f2a] flex items-center justify-between text-[#87929a] font-mono text-[12px]">
              <span>Execution Queue:</span>
              <span className="text-[#38bdf8] font-semibold">&lt;12ms alert speed</span>
            </div>
          </div>

          {/* Feature 3 (Interactive: click to open Ledger) */}
          <div
            onClick={onOpenLedger}
            className="p-6 sm:p-7 rounded-2xl bg-[#171b26] border border-[#1c1f2a] flex flex-col justify-between space-y-6 shadow-sm hover:border-[#05e777]/50 transition-all cursor-pointer group"
          >
            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <div className="w-12 h-12 rounded-xl bg-[#38bdf8]/15 border border-[#38bdf8]/30 flex items-center justify-center text-[#8ed5ff]">
                  <span className="material-symbols-outlined text-[24px]">query_stats</span>
                </div>
                <span className="px-2.5 py-1 rounded bg-[#262a35] text-[#87929a] font-mono text-[11px] group-hover:text-[#8ed5ff]">
                  Verified Ledger ↗
                </span>
              </div>
              <div>
                <h3 className="text-lg sm:text-xl text-[#dfe2f1] font-semibold flex items-center gap-2">
                  <span>Performance Dashboard</span>
                </h3>
                <p className="text-sm text-[#bdc8d1] mt-2 leading-relaxed">
                  View every past prediction to see exactly how the AI has performed over the last thirty days.
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-[#1c1f2a] flex items-center justify-between text-[#87929a] font-mono text-[12px]">
              <span>Sample Validation:</span>
              <span className="text-[#05e777] font-semibold">84.6% Win Rate</span>
            </div>
          </div>

          {/* Feature 4 (Interactive: click to test Risk Co-Pilot) */}
          <div
            onClick={onOpenTerminal}
            className="p-6 sm:p-7 rounded-2xl bg-[#171b26] border border-[#1c1f2a] flex flex-col justify-between space-y-6 shadow-sm hover:border-[#ffbcb8]/50 transition-all cursor-pointer group"
          >
            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <div className="w-12 h-12 rounded-xl bg-[#ff938d]/15 border border-[#ff938d]/30 flex items-center justify-center text-[#ffbcb8]">
                  <span className="material-symbols-outlined text-[24px]">shield</span>
                </div>
                <span className="px-2.5 py-1 rounded bg-[#262a35] text-[#87929a] font-mono text-[11px] group-hover:text-[#ffbcb8]">
                  Dynamic Stops ↗
                </span>
              </div>
              <div>
                <h3 className="text-lg sm:text-xl text-[#dfe2f1] font-semibold">
                  Risk Co-Pilot
                </h3>
                <p className="text-sm text-[#bdc8d1] mt-2 leading-relaxed">
                  Receive automated warnings when market volatility is too high for safe entry, helping you protect your capital.
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-[#1c1f2a] flex items-center justify-between text-[#87929a] font-mono text-[12px]">
              <span>Capital Guard:</span>
              <span className="text-[#ffdad7] font-semibold">Auto Capital Shield</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
