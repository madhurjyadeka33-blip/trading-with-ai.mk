import React from 'react';

interface FooterProps {
  onNavigate: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="w-full bg-[#0a0e18] text-[#bdc8d1] border-t border-[#1c1f2a]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* 5-Column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">
          {/* Brand & Tech Telemetry */}
          <div className="space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-[#262a35] border border-[#3e484f]/40 flex items-center justify-center text-[#8ed5ff]">
                <span className="material-symbols-outlined text-[16px]">insights</span>
              </div>
              <span className="font-semibold text-[16px] tracking-tight text-[#dfe2f1]">
                Trading with AI
              </span>
            </div>
            <p className="text-xs text-[#bdc8d1] leading-relaxed">
              Sub-second algorithmic edge and predictive models engineered for active intraday market participants.
            </p>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded bg-[#171b26] border border-[#1c1f2a]">
              <span className="w-2 h-2 rounded-full bg-[#05e777] animate-pulse" />
              <span className="font-mono text-[11px] text-[#dfe2f1]">
                API Latency: 12ms | Cluster Active
              </span>
            </div>
          </div>

          {/* Platform */}
          <div>
            <div className="font-mono text-[11px] uppercase tracking-wider text-[#87929a] font-semibold mb-3">
              Platform
            </div>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onNavigate('terminal')}
                  className="hover:text-[#dfe2f1] transition-colors cursor-pointer text-left"
                >
                  Neural Execution Engine
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('performance')}
                  className="hover:text-[#dfe2f1] transition-colors cursor-pointer text-left"
                >
                  Backtested Models
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('terminal')}
                  className="hover:text-[#dfe2f1] transition-colors cursor-pointer text-left"
                >
                  Order Book Flow
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('pricing')}
                  className="hover:text-[#dfe2f1] transition-colors cursor-pointer text-left"
                >
                  Institutional Nodes
                </button>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <div className="font-mono text-[11px] uppercase tracking-wider text-[#87929a] font-semibold mb-3">
              Resources
            </div>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onNavigate('faq')}
                  className="hover:text-[#dfe2f1] transition-colors cursor-pointer text-left"
                >
                  Documentation & FAQ
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('faq')}
                  className="hover:text-[#dfe2f1] transition-colors cursor-pointer text-left"
                >
                  24/7 Desk Support
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('performance')}
                  className="hover:text-[#dfe2f1] transition-colors cursor-pointer text-left"
                >
                  Exchange Latency Status
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('how-it-works')}
                  className="hover:text-[#dfe2f1] transition-colors cursor-pointer text-left"
                >
                  Quant Playbook
                </button>
              </li>
            </ul>
          </div>

          {/* Compliance & Risk */}
          <div>
            <div className="font-mono text-[11px] uppercase tracking-wider text-[#87929a] font-semibold mb-3">
              Compliance & Risk
            </div>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#terms" className="hover:text-[#dfe2f1] transition-colors">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#privacy" className="hover:text-[#dfe2f1] transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#risk" className="hover:text-[#dfe2f1] transition-colors">
                  Risk Disclosure
                </a>
              </li>
              <li>
                <a href="#security" className="hover:text-[#dfe2f1] transition-colors">
                  SOC2 Security Protocol
                </a>
              </li>
            </ul>
          </div>

          {/* Desks & Coverage */}
          <div>
            <div className="font-mono text-[11px] uppercase tracking-wider text-[#87929a] font-semibold mb-3">
              Desks & Coverage
            </div>
            <p className="text-xs text-[#bdc8d1] mb-3 leading-relaxed">
              Equities, FX Pairs, Index Futures, and High-Throughput Digital Assets.
            </p>
            <div className="font-mono text-[11px] text-[#8ed5ff] tracking-widest font-semibold">
              NYC • LON • TYO • SGP
            </div>
          </div>
        </div>

        {/* Regulatory & Risk Disclaimer Box */}
        <div className="p-4 sm:p-5 rounded-xl bg-[#171b26] border border-[#1c1f2a] mb-8">
          <div className="flex items-start gap-3">
            <span className="material-symbols-outlined text-[#87929a] text-[18px] shrink-0 mt-0.5">
              shield
            </span>
            <p className="text-[11px] text-[#87929a] leading-relaxed">
              Regulatory & Risk Disclaimer: Trading foreign exchange, indices, equities, and algorithmic instruments carries substantial risk of capital loss and is not appropriate for all investors. Quantitative machine-learning signals, predictive probabilities, and statistical models generated by Trading with AI are provided strictly for informational and computational analysis purposes. Past backtested performance metrics do not guarantee future returns. Leverage can amplify both losses and gains. Ensure comprehensive review of your risk profile before executing live capital.
            </p>
          </div>
        </div>

        {/* Bottom Copyright Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] font-mono text-[#87929a] pt-4 border-t border-[#1c1f2a]">
          <div>
            © 2025 Trading with AI Inc. Institutional algorithmic architectures. All rights reserved.
          </div>
          <div className="flex items-center gap-4">
            <a href="#terms" className="hover:text-[#dfe2f1] transition-colors">Terms</a>
            <a href="#privacy" className="hover:text-[#dfe2f1] transition-colors">Privacy</a>
            <a href="#risk" className="hover:text-[#dfe2f1] transition-colors">Risk</a>
            <a href="#support" className="hover:text-[#dfe2f1] transition-colors">Support</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
