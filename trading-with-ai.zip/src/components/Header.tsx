import React, { useState } from 'react';

interface HeaderProps {
  activeTab: string;
  onNavigate: (tab: string) => void;
  onOpenTrial: () => void;
  onOpenSignIn: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onNavigate,
  onOpenTrial,
  onOpenSignIn,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'overview', label: 'Overview' },
    { id: 'how-it-works', label: 'How it Works' },
    { id: 'features', label: 'Features' },
    { id: 'performance', label: 'Performance' },
    { id: 'pricing', label: 'Pricing' },
    { id: 'faq', label: 'FAQ' },
    { id: 'terminal', label: 'Live Cockpit' },
  ];

  const handleNavClick = (id: string, e: React.MouseEvent) => {
    e.preventDefault();
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 w-full z-50 bg-[#0f131d]/90 backdrop-blur-xl border-b border-[#1c1f2a] shadow-[0_1px_8px_rgba(0,0,0,0.5)]">
      <div className="h-16 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Brand Zone */}
        <div className="flex items-center gap-8">
          <a
            href="#overview"
            onClick={(e) => handleNavClick('overview', e)}
            className="flex items-center gap-2.5 text-inherit no-underline group"
          >
            <div className="w-8 h-8 rounded-lg bg-[#262a35] border border-[#3e484f]/40 flex items-center justify-center text-[#8ed5ff] group-hover:border-[#38bdf8]/50 transition-colors shadow-sm">
              <span className="material-symbols-outlined text-[19px]">insights</span>
            </div>
            <span className="font-semibold text-[17px] tracking-tight text-[#dfe2f1] font-sans">
              Trading with AI
            </span>
          </a>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-1 text-[14px]">
            {navItems.map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                onClick={(e) => handleNavClick(item.id, e)}
                className={`px-3 py-1.5 rounded-lg font-medium transition-all whitespace-nowrap ${
                  activeTab === item.id
                    ? 'bg-[#1c1f2a] text-[#8ed5ff] shadow-inner'
                    : 'text-[#bdc8d1] hover:text-[#dfe2f1] hover:bg-[#262a35]/60'
                }`}
              >
                {item.label}
              </a>
            ))}
          </nav>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onOpenSignIn}
            className="hidden sm:inline-flex items-center px-3.5 py-1.5 rounded-lg bg-[#1c1f2a] border border-[#3e484f]/40 text-[#dfe2f1] font-medium text-[13px] hover:bg-[#262a35] hover:border-[#87929a] transition-all cursor-pointer"
          >
            Sign In
          </button>

          <button
            type="button"
            onClick={onOpenTrial}
            className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-[#38bdf8] text-[#004965] font-semibold text-[13px] hover:bg-[#8ed5ff] hover:shadow-[0_0_15px_rgba(56,189,248,0.35)] active:scale-95 transition-all cursor-pointer shadow-md"
          >
            <span className="material-symbols-outlined text-[16px]">bolt</span>
            <span>Start 7-Day Trial</span>
          </button>

          {/* Profile indicator */}
          <button
            type="button"
            onClick={onOpenSignIn}
            title="Trader Profile"
            className="w-8 h-8 rounded-full bg-[#8ed5ff] text-[#00354a] flex items-center justify-center hover:brightness-110 transition-all cursor-pointer shadow-sm"
          >
            <span className="material-symbols-outlined text-[18px]">person</span>
          </button>

          {/* Mobile Menu Toggle */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-1.5 rounded-lg bg-[#1c1f2a] text-[#dfe2f1] hover:bg-[#262a35] transition-colors"
            aria-label="Toggle navigation menu"
          >
            <span className="material-symbols-outlined text-[22px]">
              {mobileMenuOpen ? 'close' : 'menu'}
            </span>
          </button>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden px-4 py-3 bg-[#171b26] border-b border-[#1c1f2a] space-y-1 shadow-2xl animate-in slide-in-from-top-2 duration-200">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={(e) => handleNavClick(item.id, e)}
              className={`w-full text-left px-3 py-2 rounded-lg text-[14px] font-medium transition-colors ${
                activeTab === item.id
                  ? 'bg-[#1c1f2a] text-[#8ed5ff]'
                  : 'text-[#bdc8d1] hover:text-[#dfe2f1] hover:bg-[#262a35]'
              }`}
            >
              {item.label}
            </button>
          ))}
          <div className="pt-2 border-t border-[#1c1f2a] flex gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenSignIn();
              }}
              className="flex-1 py-2 text-center text-[13px] font-medium rounded-lg bg-[#1c1f2a] text-[#dfe2f1]"
            >
              Sign In
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenTrial();
              }}
              className="flex-1 py-2 text-center text-[13px] font-semibold rounded-lg bg-[#38bdf8] text-[#004965]"
            >
              Start Trial
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
