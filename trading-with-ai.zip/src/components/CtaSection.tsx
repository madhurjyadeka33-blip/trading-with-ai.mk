import React, { useState } from 'react';

interface CtaSectionProps {
  onSuccess: (email: string) => void;
}

export const CtaSection: React.FC<CtaSectionProps> = ({ onSuccess }) => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) return;
    setSubmitted(true);
    onSuccess(email);
  };

  return (
    <section className="w-full px-4 sm:px-6 lg:px-8 py-20 bg-[#0a0e18] border-t border-[#1c1f2a]">
      <div className="max-w-4xl mx-auto">
        <div className="relative overflow-hidden p-8 sm:p-12 rounded-3xl bg-[#171b26] border border-[#262a35] text-center flex flex-col items-center gap-6 shadow-2xl">
          {/* Subtle Glow Overlay */}
          <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#38bdf8]/15 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 right-1/4 w-80 h-80 bg-[#7dffa2]/5 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col items-center gap-2 max-w-xl">
            <span className="font-mono text-[11px] text-[#38bdf8] uppercase tracking-widest font-semibold">
              ZERO EMOTIONAL DRIFT
            </span>
            <h2 className="text-2xl sm:text-4xl font-bold text-[#dfe2f1] tracking-tight">
              Ready to upgrade your trading strategy?
            </h2>
            <p className="text-sm sm:text-base text-[#bdc8d1]">
              Join thousands of traders replacing emotional guesses with mathematical edge.
            </p>
          </div>

          {submitted ? (
            <div className="relative z-10 p-4 rounded-xl bg-[#00622e]/30 border border-[#05e777]/50 text-[#7dffa2] flex items-center gap-3 animate-in fade-in">
              <span className="material-symbols-outlined text-[24px]">verified</span>
              <div className="text-left">
                <p className="font-semibold text-sm">7-Day Free Trial Provisioned!</p>
                <p className="text-xs text-[#bdc8d1]">We sent activation credentials to {email}. Check your inbox.</p>
              </div>
            </div>
          ) : (
            /* Inline Subscription Form */
            <form
              onSubmit={handleSubmit}
              className="relative z-10 flex flex-col sm:flex-row items-center gap-2.5 w-full max-w-lg mt-2"
            >
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your work or trading email..."
                required
                className="w-full px-4 py-3.5 rounded-xl bg-[#0a0e18] border border-[#262a35] text-[#dfe2f1] placeholder:text-[#87929a] font-mono text-[13px] focus:outline-none focus:border-[#38bdf8] transition-colors shadow-inner"
              />
              <button
                type="submit"
                className="w-full sm:w-auto shrink-0 px-6 py-3.5 rounded-xl bg-[#38bdf8] hover:bg-[#8ed5ff] text-[#00354a] font-semibold text-[14px] shadow-lg shadow-[#38bdf8]/20 transition-all cursor-pointer active:scale-[0.98] whitespace-nowrap"
              >
                Get Started Now
              </button>
            </form>
          )}

          {/* Trust micro-copy */}
          <div className="relative z-10 font-mono text-[11px] text-[#87929a] pt-1">
            Instant activation • 7-day free trial • Cancel anytime
          </div>
        </div>
      </div>
    </section>
  );
};
