import React, { useState } from 'react';

interface PricingSectionProps {
  onSelectPlan: (plan: 'basic' | 'pro') => void;
}

export const PricingSection: React.FC<PricingSectionProps> = ({ onSelectPlan }) => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');

  const basicPrice = billingCycle === 'monthly' ? 50 : 40;
  const proPrice = billingCycle === 'monthly' ? 200 : 160;

  return (
    <section id="pricing" className="w-full px-4 sm:px-6 lg:px-8 py-20 bg-[#0a0e18] border-y border-[#1c1f2a]">
      <div className="max-w-7xl mx-auto flex flex-col gap-12">
        {/* Section Header */}
        <div className="flex flex-col items-center text-center max-w-xl mx-auto space-y-3">
          <span className="font-mono text-[11px] uppercase tracking-widest text-[#38bdf8] font-semibold">
            PLAN ARCHITECTURE
          </span>
          <h2 className="text-2xl sm:text-4xl font-bold text-[#dfe2f1] tracking-tight">
            Transparent, simple pricing
          </h2>
          <p className="text-sm sm:text-base text-[#bdc8d1]">
            Invest in discipline. Upgrade or cancel anytime.
          </p>

          {/* Billing Switcher */}
          <div className="inline-flex items-center p-1 rounded-xl bg-[#171b26] border border-[#262a35] mt-2">
            <button
              type="button"
              onClick={() => setBillingCycle('monthly')}
              className={`px-3.5 py-1.5 rounded-lg text-[13px] font-medium transition-all cursor-pointer ${
                billingCycle === 'monthly'
                  ? 'bg-[#262a35] text-[#dfe2f1] shadow-sm'
                  : 'text-[#87929a] hover:text-[#dfe2f1]'
              }`}
            >
              Monthly Billing
            </button>
            <button
              type="button"
              onClick={() => setBillingCycle('annual')}
              className={`px-3.5 py-1.5 rounded-lg text-[13px] font-medium transition-all flex items-center gap-1.5 cursor-pointer ${
                billingCycle === 'annual'
                  ? 'bg-[#262a35] text-[#dfe2f1] shadow-sm'
                  : 'text-[#87929a] hover:text-[#dfe2f1]'
              }`}
            >
              <span>Annual Billing</span>
              <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-[#05e777]/20 text-[#05e777]">
                -20%
              </span>
            </button>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto w-full items-stretch">
          {/* Basic Plan */}
          <div className="p-7 sm:p-8 rounded-2xl bg-[#171b26] border border-[#1c1f2a] flex flex-col justify-between space-y-8 shadow-sm hover:border-[#3e484f] transition-all">
            <div className="space-y-6">
              <div>
                <h3 className="text-2xl font-bold text-[#dfe2f1]">Basic Plan</h3>
                <p className="text-xs sm:text-sm text-[#bdc8d1] mt-1.5">
                  Perfect for part-time traders building consistency.
                </p>
              </div>

              <div className="flex items-baseline gap-1.5">
                <span className="font-mono text-4xl sm:text-5xl font-bold text-[#dfe2f1]">
                  ${basicPrice}
                </span>
                <span className="text-sm text-[#87929a] font-mono">
                  {billingCycle === 'annual' ? '/month (billed annually)' : '/month'}
                </span>
              </div>

              {/* Feature list */}
              <ul className="space-y-3 pt-2 text-sm text-[#dfe2f1]">
                <li className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-[#05e777] text-[19px]">check_circle</span>
                  <span>Daily market direction signals</span>
                </li>
                <li className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-[#05e777] text-[19px]">check_circle</span>
                  <span>Email alerts</span>
                </li>
                <li className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-[#05e777] text-[19px]">check_circle</span>
                  <span>Performance dashboard</span>
                </li>
                <li className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-[#05e777] text-[19px]">check_circle</span>
                  <span>Community access</span>
                </li>
              </ul>
            </div>

            <button
              type="button"
              onClick={() => onSelectPlan('basic')}
              className="w-full py-3.5 rounded-xl bg-[#262a35] hover:bg-[#313540] border border-[#3e484f]/60 text-[#dfe2f1] font-semibold text-[14px] transition-all cursor-pointer shadow-sm active:scale-[0.98]"
            >
              Get Started with Basic
            </button>
          </div>

          {/* Pro Plan (Most Popular) */}
          <div className="p-7 sm:p-8 rounded-2xl bg-[#1c1f2a] border border-[#38bdf8]/50 flex flex-col justify-between space-y-8 shadow-2xl relative overflow-hidden group">
            {/* Subtle glow edge */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#38bdf8]/10 blur-2xl pointer-events-none" />

            <div className="space-y-6 relative">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-2xl font-bold text-[#8ed5ff]">Pro Plan</h3>
                  <p className="text-xs sm:text-sm text-[#bdc8d1] mt-1.5">
                    For active day traders seeking maximum speed and edge.
                  </p>
                </div>
                <span className="px-3 py-1 rounded-full bg-[#38bdf8] text-[#004965] font-mono text-[11px] font-bold tracking-wider uppercase shadow-sm">
                  MOST POPULAR
                </span>
              </div>

              <div className="flex items-baseline gap-1.5">
                <span className="font-mono text-4xl sm:text-5xl font-bold text-[#dfe2f1]">
                  ${proPrice}
                </span>
                <span className="text-sm text-[#87929a] font-mono">
                  {billingCycle === 'annual' ? '/month (billed annually)' : '/month'}
                </span>
              </div>

              {/* Feature list */}
              <ul className="space-y-3 pt-2 text-sm text-[#dfe2f1]">
                <li className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-[#05e777] text-[19px]">check_circle</span>
                  <span className="font-semibold text-[#8ed5ff]">Real-time push notifications</span>
                </li>
                <li className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-[#05e777] text-[19px]">check_circle</span>
                  <span>API access for automated execution</span>
                </li>
                <li className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-[#05e777] text-[19px]">check_circle</span>
                  <span>Priority support desk</span>
                </li>
                <li className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-[#05e777] text-[19px]">check_circle</span>
                  <span>Everything in Basic</span>
                </li>
                <li className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-[#05e777] text-[19px]">check_circle</span>
                  <span className="font-semibold text-[#7dffa2]">Advanced Risk Co-Pilot volatility filters</span>
                </li>
              </ul>
            </div>

            <button
              type="button"
              onClick={() => onSelectPlan('pro')}
              className="w-full py-3.5 rounded-xl bg-[#38bdf8] hover:bg-[#8ed5ff] text-[#00354a] font-semibold text-[15px] shadow-lg shadow-[#38bdf8]/25 transition-all cursor-pointer active:scale-[0.98] flex items-center justify-center gap-2"
            >
              <span className="material-symbols-outlined text-[18px]">bolt</span>
              <span>Start 7-Day Pro Trial</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
