import React, { useState, useEffect } from 'react';
import { TICKERS_DATA } from '../data/mockTradingData';

interface HeroSectionProps {
  onStartTrial: () => void;
  onViewPerformance: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onStartTrial,
  onViewPerformance,
}) => {
  const [selectedTickerKey, setSelectedTickerKey] = useState<string>('SPY');
  const [selectedTimeframe, setSelectedTimeframe] = useState<string>('15m');
  const [simulatingTicks, setSimulatingTicks] = useState<boolean>(true);
  const [tickOffset, setTickOffset] = useState<number>(0);

  const activeTicker = TICKERS_DATA[selectedTickerKey] || TICKERS_DATA['SPY'];

  // Real-time subtle tick pulsing simulation for live market feel
  useEffect(() => {
    if (!simulatingTicks) return;
    const interval = setInterval(() => {
      setTickOffset((prev) => (prev + 1) % 100);
    }, 2800);
    return () => clearInterval(interval);
  }, [simulatingTicks]);

  const currentPrice = (
    activeTicker.price +
    (selectedTickerKey === 'BTC/USD'
      ? Math.sin(tickOffset) * 45
      : Math.sin(tickOffset) * 0.35)
  ).toFixed(activeTicker.assetClass === 'FOREX' ? 4 : 2);

  const isBullish = activeTicker.signal.direction === 'BULLISH';

  return (
    <section className="relative w-full px-4 sm:px-6 lg:px-8 pt-8 pb-16 overflow-hidden">
      {/* Ambient cyan and emerald background glows */}
      <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#38bdf8]/10 blur-[110px] pointer-events-none rounded-full" />
      <div className="absolute top-72 -left-20 w-80 h-80 bg-[#7dffa2]/5 blur-[100px] pointer-events-none rounded-full" />
      <div className="absolute bottom-10 right-0 w-96 h-96 bg-[#38bdf8]/5 blur-[120px] pointer-events-none rounded-full" />

      <div className="relative max-w-7xl mx-auto flex flex-col items-center text-center space-y-6">
        {/* Eyebrow Badge */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#262a35]/90 border border-[#3e484f]/60 shadow-sm backdrop-blur-md">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#7dffa2] opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-[#05e777]" />
          </span>
          <span className="font-mono text-[11px] font-semibold text-[#7dffa2] uppercase tracking-wider">
            Institutional-Grade Market Intelligence
          </span>
        </div>

        {/* Headline */}
        <h1 className="text-3xl sm:text-5xl lg:text-[54px] font-bold text-[#dfe2f1] tracking-tight leading-[1.12] max-w-3xl">
          Trade with data instead of doubt
        </h1>

        {/* Subheadline */}
        <p className="text-base sm:text-lg text-[#bdc8d1] max-w-2xl leading-relaxed">
          Get high-accuracy AI predictions on market direction so you can make informed decisions and stop trading on emotion.
        </p>

        {/* Action Buttons */}
        <div className="w-full flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          <button
            type="button"
            onClick={onStartTrial}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-[#38bdf8] text-[#00354a] font-semibold text-[15px] hover:bg-[#8ed5ff] hover:brightness-105 shadow-lg shadow-[#38bdf8]/20 transition-all active:scale-[0.98] cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">bolt</span>
            <span>Start your 7-day trial</span>
            <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
          </button>
          <button
            type="button"
            onClick={onViewPerformance}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-[#262a35] border border-[#3e484f]/60 text-[#dfe2f1] font-medium text-[14px] hover:bg-[#313540] hover:border-[#87929a] transition-all cursor-pointer"
          >
            <span className="material-symbols-outlined text-[#8ed5ff] text-[18px]">query_stats</span>
            <span>View historical performance</span>
          </button>
        </div>

        {/* Micro-Trust Note */}
        <div className="font-mono text-[11px] sm:text-[12px] text-[#87929a] flex items-center justify-center gap-2 flex-wrap pt-1">
          <span>No credit card required for trial</span>
          <span className="text-[#313540]">•</span>
          <span>Cancel anytime</span>
          <span className="text-[#313540]">•</span>
          <span className="text-[#7dffa2] font-semibold flex items-center gap-1">
            <span className="material-symbols-outlined text-[14px]">verified</span>
            84.6% 30-day signal accuracy
          </span>
        </div>

        {/* Hero Interactive Terminal Cockpit */}
        <div className="w-full max-w-5xl pt-4">
          <div className="w-full rounded-2xl bg-[#171b26] border border-[#1c1f2a] p-4 sm:p-5 shadow-2xl relative text-left backdrop-blur-md">
            
            {/* Terminal / Cockpit Header */}
            <div className="flex flex-wrap items-center justify-between gap-3 pb-3 mb-3 border-b border-[#1c1f2a]">
              {/* Asset Selector Tabs */}
              <div className="flex items-center gap-1.5 flex-wrap">
                {(['SPY', 'BTC/USD', 'NVDA', 'TSLA', 'EUR/USD'] as const).map((sym) => {
                  const isActive = selectedTickerKey === sym;
                  return (
                    <button
                      key={sym}
                      type="button"
                      onClick={() => setSelectedTickerKey(sym)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-mono text-[12px] font-semibold transition-all cursor-pointer ${
                        isActive
                          ? 'bg-[#313540] text-[#dfe2f1] border border-[#8ed5ff]/40 shadow-sm'
                          : 'bg-[#1c1f2a]/70 text-[#87929a] hover:text-[#dfe2f1] hover:bg-[#262a35]'
                      }`}
                    >
                      <span>{sym}</span>
                      {sym === 'SPY' && <span className="hidden sm:inline text-[10px] text-[#bdc8d1] font-sans font-normal">S&P 500 ETF</span>}
                      {sym === 'BTC/USD' && <span className="hidden sm:inline text-[10px] text-[#bdc8d1] font-sans font-normal">Crypto</span>}
                    </button>
                  );
                })}
              </div>

              {/* Status and Timeframe Controls */}
              <div className="flex items-center gap-2 sm:gap-4 font-mono text-[11px]">
                {/* Timeframe switchers */}
                <div className="hidden sm:flex items-center bg-[#0a0e18] p-0.5 rounded-md border border-[#1c1f2a]">
                  {(['1m', '5m', '15m', '1H', '1D'] as const).map((tf) => (
                    <button
                      key={tf}
                      type="button"
                      onClick={() => setSelectedTimeframe(tf)}
                      className={`px-2 py-0.5 rounded text-[11px] font-semibold cursor-pointer transition-colors ${
                        selectedTimeframe === tf
                          ? 'bg-[#262a35] text-[#8ed5ff]'
                          : 'text-[#87929a] hover:text-[#dfe2f1]'
                      }`}
                    >
                      {tf}
                    </button>
                  ))}
                </div>

                <span className="text-[#87929a] hidden md:inline">REGULAR TRADING HOURS</span>
                
                {/* Live Feed indicator */}
                <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#00622e]/20 border border-[#05e777]/30 text-[#05e777]">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#05e777] opacity-75" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-[#05e777]" />
                  </span>
                  <span className="font-bold tracking-wider text-[11px]">LIVE FEED</span>
                </div>

                {/* Simulate ticks toggle */}
                <button
                  type="button"
                  onClick={() => setSimulatingTicks(!simulatingTicks)}
                  title={simulatingTicks ? 'Pause live ticks' : 'Resume live ticks'}
                  className="p-1 rounded bg-[#1c1f2a] text-[#bdc8d1] hover:text-[#8ed5ff] transition-colors"
                >
                  <span className="material-symbols-outlined text-[16px]">
                    {simulatingTicks ? 'pause' : 'play_arrow'}
                  </span>
                </button>
              </div>
            </div>

            {/* Secondary Warning Banner (matching screenshot) */}
            {activeTicker.secondaryWarning && (
              <div className="mb-3 px-3 py-1.5 rounded-lg bg-[#93000a]/15 border border-[#ffb4ab]/20 flex flex-wrap items-center justify-between gap-2 text-[12px] font-mono">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#ffb4ab] text-[16px]">warning</span>
                  <span className="text-[#dfe2f1] font-semibold">
                    {activeTicker.secondaryWarning.symbol}: {activeTicker.secondaryWarning.warning}
                  </span>
                  <span className="px-1.5 py-0.2 rounded bg-[#ffb4ab]/20 text-[#ffdad7] text-[10px] font-bold">
                    {activeTicker.secondaryWarning.riskLevel}
                  </span>
                </div>
                <div className="text-[#ffb4ab] text-[11px] flex items-center gap-2">
                  <span>Pivot: ${activeTicker.secondaryWarning.pivot.toLocaleString()}</span>
                  <span>Target: ${activeTicker.secondaryWarning.target.toLocaleString()}</span>
                  <span className="text-[#ffdad7] underline decoration-dotted">{activeTicker.secondaryWarning.note}</span>
                </div>
              </div>
            )}

            {/* Price & Signal Indicator Banner */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 mb-3.5">
              {/* Primary AI Vector Detected Card */}
              <div className="p-3 rounded-xl bg-[#1c1f2a] border border-[#262a35] flex flex-col justify-between">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-[#87929a] uppercase tracking-wider">AI VECTOR DETECTED</span>
                  <span className="px-2 py-0.5 rounded bg-[#05e777]/20 border border-[#05e777]/30 text-[#05e777] font-mono text-[11px] font-semibold">
                    +{activeTicker.signal.confidence}% Conf
                  </span>
                </div>
                <div className="mt-2 flex items-baseline gap-1">
                  <span className={`text-[17px] font-bold font-sans tracking-tight ${isBullish ? 'text-[#05e777]' : 'text-[#ffb4ab]'}`}>
                    {activeTicker.signal.type}
                  </span>
                </div>
                <div className="mt-1.5 flex items-center justify-between font-mono text-[11px] text-[#bdc8d1]">
                  <span>Live: ${currentPrice}</span>
                  <span className="text-[#8ed5ff]">R:R {activeTicker.signal.riskReward}</span>
                </div>
              </div>

              {/* Entry Price Card */}
              <div className="p-3 rounded-xl bg-[#1c1f2a] border border-[#262a35] flex flex-col justify-between">
                <span className="text-[10px] font-mono text-[#87929a] uppercase tracking-wider">ENTRY PRICE</span>
                <div className="mt-1 text-[20px] font-mono font-bold text-[#dfe2f1]">
                  ${activeTicker.signal.entry.toLocaleString()}
                </div>
                <span className="mt-1 text-[11px] font-mono text-[#7dffa2]">Model Validated Target Range</span>
              </div>

              {/* Target Price Card */}
              <div className="p-3 rounded-xl bg-[#1c1f2a] border border-[#262a35] flex flex-col justify-between">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-[#87929a] uppercase tracking-wider">TARGET PRICE</span>
                  <span className="text-[10px] font-mono text-[#38bdf8] uppercase">T1 BREAKOUT</span>
                </div>
                <div className="mt-1 text-[20px] font-mono font-bold text-[#05e777]">
                  ${activeTicker.signal.target.toLocaleString()}
                </div>
                <span className="mt-1 text-[11px] font-mono text-[#8ed5ff]">
                  {isBullish ? '+' : '-'}{Math.abs(((activeTicker.signal.target - activeTicker.signal.entry) / activeTicker.signal.entry) * 100).toFixed(2)}% Expected
                </span>
              </div>

              {/* Trailing Stop Card */}
              <div className="p-3 rounded-xl bg-[#1c1f2a] border border-[#262a35] flex flex-col justify-between">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-[#87929a] uppercase tracking-wider">TRAILING STOP</span>
                  <span className="text-[10px] font-mono text-[#ffb4ab] uppercase">CAPITAL SHIELD</span>
                </div>
                <div className="mt-1 text-[20px] font-mono font-bold text-[#ffb4ab]">
                  ${activeTicker.signal.stop.toLocaleString()}
                </div>
                <span className="mt-1 text-[11px] font-mono text-[#87929a]">
                  -{Math.abs(((activeTicker.signal.entry - activeTicker.signal.stop) / activeTicker.signal.entry) * 100).toFixed(2)}% Max Risk
                </span>
              </div>
            </div>

            {/* Chart Area Simulation with SVG Candlesticks & Trajectory */}
            <div className="rounded-xl bg-[#0a0e18] border border-[#1c1f2a] p-3 sm:p-4 relative overflow-hidden">
              {/* Chart overlay meta */}
              <div className="flex items-center justify-between text-[#87929a] font-mono text-[11px] sm:text-[12px] mb-2 border-b border-[#1c1f2a] pb-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-[#38bdf8] font-semibold">MODEL: {activeTicker.chart.model}</span>
                  <span className="text-[#3e484f]">•</span>
                  <span>{selectedTimeframe.toUpperCase()} TIMEFRAME</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-[#7dffa2]">RSI: {activeTicker.chart.rsi}</span>
                  <span className="hidden sm:inline text-[#dfe2f1]">{activeTicker.chart.condition}</span>
                </div>
              </div>

              {/* SVG Candlesticks & Trajectory Chart Simulation */}
              <svg className="w-full h-48 sm:h-56" preserveAspectRatio="none" viewBox="0 0 600 210">
                <defs>
                  <linearGradient id="bullArea" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0%" stopColor="#05e777" stopOpacity="0.25" />
                    <stop offset="100%" stopColor="#05e777" stopOpacity="0.0" />
                  </linearGradient>
                  <linearGradient id="aiRay" x1="0" x2="1" y1="0" y2="0">
                    <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.3" />
                    <stop offset="100%" stopColor="#38bdf8" stopOpacity="1" />
                  </linearGradient>
                  <linearGradient id="projectionCone" x1="0" x2="1" y1="0" y2="0">
                    <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.22" />
                    <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.03" />
                  </linearGradient>
                </defs>

                {/* Grid Horizontal Lines */}
                <line x1="0" x2="600" y1="40" y2="40" stroke="#1c1f2a" strokeDasharray="4 4" />
                <line x1="0" x2="600" y1="90" y2="90" stroke="#1c1f2a" strokeDasharray="4 4" />
                <line x1="0" x2="600" y1="140" y2="140" stroke="#1c1f2a" strokeDasharray="4 4" />
                <line x1="0" x2="600" y1="180" y2="180" stroke="#1c1f2a" strokeDasharray="4 4" />

                {/* Projection Cone Background Fill */}
                <polygon points="400,60 590,20 590,55 400,60" fill="url(#projectionCone)" />

                {/* Price Area Fill underneath */}
                <path
                  d="M 0 160 L 40 145 L 80 150 L 120 135 L 160 140 L 200 120 L 240 125 L 280 100 L 320 105 L 360 85 L 400 60 L 480 45 L 590 28 L 600 28 L 600 200 L 0 200 Z"
                  fill="url(#bullArea)"
                />

                {/* Main Candlestick Wicks & Bodies */}
                {/* Candle 1 */}
                <line x1="40" x2="40" y1="130" y2="165" stroke="#7dffa2" strokeWidth="1.5" />
                <rect x="36" y="138" width="8" height="15" rx="1" fill="#05e777" />

                {/* Candle 2 (Red) */}
                <line x1="80" x2="80" y1="135" y2="160" stroke="#ffb4ab" strokeWidth="1.5" />
                <rect x="76" y="142" width="8" height="12" rx="1" fill="#93000a" />

                {/* Candle 3 */}
                <line x1="120" x2="120" y1="120" y2="150" stroke="#7dffa2" strokeWidth="1.5" />
                <rect x="116" y="125" width="8" height="18" rx="1" fill="#05e777" />

                {/* Candle 4 (Red) */}
                <line x1="160" x2="160" y1="115" y2="145" stroke="#ffb4ab" strokeWidth="1.5" />
                <rect x="156" y="120" width="8" height="16" rx="1" fill="#93000a" />

                {/* Candle 5 */}
                <line x1="200" x2="200" y1="100" y2="135" stroke="#7dffa2" strokeWidth="1.5" />
                <rect x="196" y="105" width="8" height="22" rx="1" fill="#05e777" />

                {/* Candle 6 */}
                <line x1="240" x2="240" y1="95" y2="130" stroke="#7dffa2" strokeWidth="1.5" />
                <rect x="236" y="100" width="8" height="20" rx="1" fill="#05e777" />

                {/* Candle 7 */}
                <line x1="280" x2="280" y1="80" y2="115" stroke="#7dffa2" strokeWidth="1.5" />
                <rect x="276" y="85" width="8" height="25" rx="1" fill="#05e777" />

                {/* Candle 8 (Red) */}
                <line x1="320" x2="320" y1="75" y2="110" stroke="#ffb4ab" strokeWidth="1.5" />
                <rect x="316" y="85" width="8" height="15" rx="1" fill="#93000a" />

                {/* Candle 9 */}
                <line x1="360" x2="360" y1="65" y2="95" stroke="#7dffa2" strokeWidth="1.5" />
                <rect x="356" y="70" width="8" height="20" rx="1" fill="#05e777" />

                {/* Candle 10 (Current Active Candle with live pulse) */}
                <line x1="400" x2="400" y1="48" y2="85" stroke="#7dffa2" strokeWidth="1.8" />
                <rect x="395" y="52" width="10" height="28" rx="1" fill="#05e777" />

                {/* Moving Average Line 20 EMA */}
                <path
                  d="M 10 160 Q 150 145 270 95 T 400 58"
                  fill="none"
                  stroke="#7bd0ff"
                  strokeWidth="2"
                  strokeLinecap="round"
                  opacity="0.8"
                />

                {/* Predictive AI Projection Ray */}
                <path
                  d="M 404 60 C 450 48, 520 35, 590 28"
                  fill="none"
                  stroke="url(#aiRay)"
                  strokeWidth="3.2"
                  strokeDasharray="6 4"
                />

                {/* Pulsing Target Node */}
                <circle cx="590" cy="28" r="6" fill="#38bdf8" opacity="0.4" className="animate-ping" />
                <circle cx="590" cy="28" r="4.5" fill="#38bdf8" />

                {/* Price Level Callout Pill */}
                <rect x="475" y="14" width="112" height="24" rx="5" fill="#1c1f2a" stroke="#38bdf8" strokeWidth="1" />
                <text x="483" y="30" fill="#8ed5ff" fontFamily="JetBrains Mono" fontSize="11" fontWeight="bold">
                  TARGET ${activeTicker.signal.target.toLocaleString()}
                </text>
              </svg>

              {/* Bottom Volume Bar Mini-Strip */}
              <div className="h-8 flex items-end gap-1.5 pt-2 border-t border-[#1c1f2a]">
                <div className="w-3 bg-[#05e777]/40 h-3 rounded-t-sm" />
                <div className="w-3 bg-[#ffb4ab]/40 h-2 rounded-t-sm" />
                <div className="w-3 bg-[#05e777]/40 h-5 rounded-t-sm" />
                <div className="w-3 bg-[#05e777]/40 h-4 rounded-t-sm" />
                <div className="w-3 bg-[#05e777]/60 h-7 rounded-t-sm" />
                <div className="w-3 bg-[#05e777]/50 h-6 rounded-t-sm" />
                <div className="w-3 bg-[#05e777]/80 h-8 rounded-t-sm" />
                <div className="w-3 bg-[#ffb4ab]/30 h-3 rounded-t-sm" />
                <div className="w-3 bg-[#05e777]/70 h-7 rounded-t-sm" />
                <div className="w-3 bg-[#05e777] h-8 rounded-t-sm animate-pulse" />
                <div className="w-3 bg-[#05e777]/80 h-6 rounded-t-sm" />
                <div className="w-3 bg-[#05e777]/90 h-8 rounded-t-sm" />

                <div className="flex-1 text-right font-mono text-[11px] text-[#87929a] pr-1 flex items-center justify-end gap-2">
                  <span className="text-[#05e777] font-semibold">{activeTicker.chart.volumeDelta}</span>
                  <span className="text-[#3e484f]">•</span>
                  <span>CONFIDENCE VECTOR: 99.4% INTEGRITY</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
};
