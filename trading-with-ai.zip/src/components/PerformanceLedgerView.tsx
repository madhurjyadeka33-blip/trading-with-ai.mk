import React, { useState } from 'react';
import { HISTORICAL_LEDGER } from '../data/mockTradingData';

interface PerformanceLedgerViewProps {
  onBackToOverview: () => void;
  onStartTrial: () => void;
}

export const PerformanceLedgerView: React.FC<PerformanceLedgerViewProps> = ({
  onBackToOverview,
  onStartTrial,
}) => {
  const [selectedAsset, setSelectedAsset] = useState<string>('ALL');
  const [selectedOutcome, setSelectedOutcome] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredItems = HISTORICAL_LEDGER.filter((item) => {
    if (selectedAsset !== 'ALL' && item.symbol !== selectedAsset) return false;
    if (selectedOutcome !== 'ALL' && item.outcome !== selectedOutcome) return false;
    if (
      searchQuery &&
      !item.symbol.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !item.id.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !item.model.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  const totalWins = HISTORICAL_LEDGER.filter((i) => i.outcome === 'WIN').length;
  const totalClosed = HISTORICAL_LEDGER.filter((i) => i.outcome !== 'OPEN').length;
  const winRate = ((totalWins / totalClosed) * 100).toFixed(1);

  return (
    <div className="w-full min-h-screen bg-[#0f131d] px-4 sm:px-6 lg:px-8 py-10">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Navigation Breadcrumb / Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-[#1c1f2a]">
          <div className="space-y-1">
            <button
              onClick={onBackToOverview}
              className="inline-flex items-center gap-1.5 text-xs font-mono text-[#8ed5ff] hover:text-[#dfe2f1] transition-colors cursor-pointer mb-1"
            >
              <span className="material-symbols-outlined text-[16px]">arrow_back</span>
              <span>Back to Overview</span>
            </button>
            <h1 className="text-2xl sm:text-3xl font-bold text-[#dfe2f1] tracking-tight">
              30-Day Verified Signal Ledger
            </h1>
            <p className="text-xs sm:text-sm text-[#bdc8d1]">
              Cryptographically timestamped trade predictions and backtested execution performance.
            </p>
          </div>

          <button
            onClick={onStartTrial}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#38bdf8] text-[#00354a] font-semibold text-xs sm:text-sm hover:bg-[#8ed5ff] transition-all shadow-md cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">bolt</span>
            <span>Start 7-Day Free Trial</span>
          </button>
        </div>

        {/* Top Quantitative KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-[#171b26] border border-[#1c1f2a]">
            <span className="font-mono text-[11px] text-[#87929a] uppercase">30D Win Rate</span>
            <div className="mt-1 font-mono text-2xl font-bold text-[#05e777]">{winRate}%</div>
            <span className="text-[11px] text-[#87929a]">8 of 9 Closed Signals</span>
          </div>
          <div className="p-4 rounded-xl bg-[#171b26] border border-[#1c1f2a]">
            <span className="font-mono text-[11px] text-[#87929a] uppercase">Net Cumulative Alpha</span>
            <div className="mt-1 font-mono text-2xl font-bold text-[#8ed5ff]">+28.4%</div>
            <span className="text-[11px] text-[#87929a]">Benchmark vs SPY +4.1%</span>
          </div>
          <div className="p-4 rounded-xl bg-[#171b26] border border-[#1c1f2a]">
            <span className="font-mono text-[11px] text-[#87929a] uppercase">Average R:R Multiple</span>
            <div className="mt-1 font-mono text-2xl font-bold text-[#dfe2f1]">1:3.1</div>
            <span className="text-[11px] text-[#87929a]">Profit Factor 2.84</span>
          </div>
          <div className="p-4 rounded-xl bg-[#171b26] border border-[#1c1f2a]">
            <span className="font-mono text-[11px] text-[#87929a] uppercase">Execution Latency</span>
            <div className="mt-1 font-mono text-2xl font-bold text-[#05e777]">10.8ms</div>
            <span className="text-[11px] text-[#87929a]">Zero Slippage Guarantee</span>
          </div>
        </div>

        {/* Filter Controls & Search */}
        <div className="p-4 rounded-xl bg-[#171b26] border border-[#1c1f2a] flex flex-wrap items-center justify-between gap-4">
          {/* Asset filter pills */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="font-mono text-[11px] text-[#87929a] mr-2">Asset:</span>
            {['ALL', 'SPY', 'BTC/USD', 'NVDA', 'TSLA', 'EUR/USD'].map((sym) => (
              <button
                key={sym}
                onClick={() => setSelectedAsset(sym)}
                className={`px-2.5 py-1 rounded text-xs font-mono font-medium transition-colors cursor-pointer ${
                  selectedAsset === sym
                    ? 'bg-[#38bdf8] text-[#00354a] font-bold'
                    : 'bg-[#0a0e18] text-[#bdc8d1] hover:text-[#dfe2f1]'
                }`}
              >
                {sym}
              </button>
            ))}
          </div>

          {/* Outcome Filter */}
          <div className="flex items-center gap-2">
            <span className="font-mono text-[11px] text-[#87929a]">Outcome:</span>
            <select
              value={selectedOutcome}
              onChange={(e) => setSelectedOutcome(e.target.value)}
              className="px-2.5 py-1 rounded bg-[#0a0e18] border border-[#262a35] text-xs font-mono text-[#dfe2f1] focus:outline-none"
            >
              <option value="ALL">All Outcomes</option>
              <option value="WIN">Wins Only</option>
              <option value="LOSS">Losses Only</option>
              <option value="OPEN">Open Positions</option>
            </select>

            {/* Search */}
            <input
              type="text"
              placeholder="Search symbol / model..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="px-3 py-1 rounded bg-[#0a0e18] border border-[#262a35] text-xs font-mono text-[#dfe2f1] placeholder:text-[#87929a] focus:outline-none focus:border-[#38bdf8]"
            />
          </div>
        </div>

        {/* Ledger Table */}
        <div className="rounded-2xl bg-[#171b26] border border-[#1c1f2a] overflow-x-auto shadow-xl">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-[#262a35] text-[#87929a] bg-[#1c1f2a]/60">
                <th className="py-3.5 px-4 font-medium">Signal ID</th>
                <th className="py-3.5 px-4 font-medium">Timestamp</th>
                <th className="py-3.5 px-4 font-medium">Symbol</th>
                <th className="py-3.5 px-4 font-medium">Action</th>
                <th className="py-3.5 px-4 font-medium">Entry</th>
                <th className="py-3.5 px-4 font-medium">Target</th>
                <th className="py-3.5 px-4 font-medium">Stop Loss</th>
                <th className="py-3.5 px-4 font-medium">Exit / Last</th>
                <th className="py-3.5 px-4 font-medium">P&L</th>
                <th className="py-3.5 px-4 font-medium">Confidence</th>
                <th className="py-3.5 px-4 font-medium">Model</th>
                <th className="py-3.5 px-4 font-medium text-right">Outcome</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1c1f2a]">
              {filteredItems.map((item) => {
                const isWin = item.outcome === 'WIN';
                const isLoss = item.outcome === 'LOSS';
                const isOpen = item.outcome === 'OPEN';

                return (
                  <tr key={item.id} className="hover:bg-[#1c1f2a]/50 transition-colors">
                    <td className="py-3.5 px-4 font-semibold text-[#8ed5ff]">{item.id}</td>
                    <td className="py-3.5 px-4 text-[#bdc8d1]">{item.date}</td>
                    <td className="py-3.5 px-4">
                      <span className="font-bold text-[#dfe2f1]">{item.symbol}</span>
                      <span className="block text-[10px] text-[#87929a]">{item.assetName}</span>
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          item.action === 'LONG'
                            ? 'bg-[#05e777]/20 text-[#05e777] border border-[#05e777]/30'
                            : 'bg-[#ffb4ab]/20 text-[#ffb4ab] border border-[#ffb4ab]/30'
                        }`}
                      >
                        {item.action}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-[#dfe2f1]">${item.entryPrice.toLocaleString()}</td>
                    <td className="py-3.5 px-4 text-[#7dffa2]">${item.targetPrice.toLocaleString()}</td>
                    <td className="py-3.5 px-4 text-[#ffb4ab]">${item.stopLoss.toLocaleString()}</td>
                    <td className="py-3.5 px-4 text-[#dfe2f1]">${item.exitPrice.toLocaleString()}</td>
                    <td
                      className={`py-3.5 px-4 font-bold ${
                        item.pnlPercent > 0 ? 'text-[#05e777]' : 'text-[#ffb4ab]'
                      }`}
                    >
                      {item.pnlPercent > 0 ? `+${item.pnlPercent}%` : `${item.pnlPercent}%`}
                    </td>
                    <td className="py-3.5 px-4 text-[#bdc8d1]">{item.confidence}%</td>
                    <td className="py-3.5 px-4 text-[#87929a] text-[11px]">{item.model}</td>
                    <td className="py-3.5 px-4 text-right">
                      {isWin && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded bg-[#05e777]/20 text-[#05e777] font-bold text-[11px]">
                          <span className="material-symbols-outlined text-[14px]">check</span>
                          WIN
                        </span>
                      )}
                      {isLoss && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded bg-[#93000a]/30 text-[#ffb4ab] font-bold text-[11px]">
                          <span className="material-symbols-outlined text-[14px]">close</span>
                          LOSS
                        </span>
                      )}
                      {isOpen && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded bg-[#38bdf8]/20 text-[#38bdf8] font-bold text-[11px]">
                          <span className="material-symbols-outlined text-[14px] animate-spin">sync</span>
                          OPEN
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
