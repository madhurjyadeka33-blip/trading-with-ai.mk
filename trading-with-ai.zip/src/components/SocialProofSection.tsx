import React from 'react';

export const SocialProofSection: React.FC = () => {
  const testimonials = [
    {
      initials: 'RD',
      role: 'Retail Day Trader',
      quote:
        '"I used to struggle with emotional entries, but having a second opinion from the AI keeps me disciplined."',
      avatarBg: 'bg-[#38bdf8]/20 text-[#8ed5ff]',
    },
    {
      initials: 'HT',
      role: 'Part-time Hobbyist Trader',
      quote:
        '"The daily signals help me filter out the noise and focus on the setups that actually have a high probability of success."',
      avatarBg: 'bg-[#05e777]/20 text-[#7dffa2]',
    },
    {
      initials: 'II',
      role: 'Independent Investor',
      quote:
        '"It is like having a quantitative analyst looking over my shoulder while I trade."',
      avatarBg: 'bg-[#38bdf8]/20 text-[#8ed5ff]',
    },
  ];

  return (
    <section className="w-full px-4 sm:px-6 lg:px-8 py-20 bg-[#0f131d]">
      <div className="max-w-7xl mx-auto flex flex-col gap-12">
        {/* Header & Community Stat Bar */}
        <div className="flex flex-col items-center text-center max-w-2xl mx-auto space-y-4">
          <h2 className="text-2xl sm:text-4xl font-bold text-[#dfe2f1] tracking-tight">
            Trusted by everyday traders
          </h2>

          {/* Live Community Stat Bar */}
          <div className="inline-flex items-center justify-center gap-3 px-5 py-2 rounded-full bg-[#262a35] border border-[#3e484f]/50 text-[#dfe2f1] font-mono text-[12px] sm:text-[13px] flex-wrap shadow-sm">
            <span className="text-[#8ed5ff] font-bold">4,200+ Active Traders</span>
            <span className="text-[#3e484f]">•</span>
            <span className="text-[#7dffa2] font-bold">$18M+ Volume Tracked</span>
            <span className="text-[#3e484f]">•</span>
            <span className="text-[#ffdad7] font-bold">4.9/5 Trader Rating</span>
          </div>
        </div>

        {/* 3-Column Testimonial Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto w-full">
          {testimonials.map((t, idx) => (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-[#1c1f2a] border border-[#262a35] flex flex-col justify-between space-y-6 shadow-md hover:border-[#3e484f] transition-all"
            >
              {/* Star Rating */}
              <div className="space-y-4">
                <div className="flex items-center gap-1 text-[#38bdf8]">
                  {[...Array(5)].map((_, i) => (
                    <span key={i} className="material-symbols-outlined text-[18px]">
                      star
                    </span>
                  ))}
                </div>
                <p className="text-sm sm:text-base text-[#dfe2f1] italic leading-relaxed">
                  {t.quote}
                </p>
              </div>

              {/* Author footer */}
              <div className="pt-4 border-t border-[#262a35] flex items-center justify-between">
                <div>
                  <p className="text-[13px] font-semibold text-[#dfe2f1]">{t.role}</p>
                  <span className="text-[11px] font-mono text-[#05e777] flex items-center gap-1">
                    <span className="material-symbols-outlined text-[13px]">verified</span>
                    Verified Trader
                  </span>
                </div>
                <div
                  className={`w-9 h-9 rounded-full ${t.avatarBg} border border-current/30 flex items-center justify-center font-mono text-[12px] font-bold`}
                >
                  {t.initials}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
