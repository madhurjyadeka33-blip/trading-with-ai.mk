import { TickerData, LedgerItem, FaqItem } from '../types/trading';

export const TICKERS_DATA: Record<string, TickerData> = {
  SPY: {
    symbol: 'SPY',
    name: 'S&P 500 ETF',
    assetClass: 'ETF',
    price: 512.40,
    change24h: 1.24,
    signal: {
      type: 'BULLISH BREAKOUT',
      direction: 'BULLISH',
      confidence: 87,
      entry: 512.40,
      target: 518.90,
      stop: 509.80,
      riskReward: '1:2.5',
      status: 'ACTIVE'
    },
    secondaryWarning: {
      symbol: 'BTC/USD',
      warning: 'BEARISH REVERSAL',
      riskLevel: 'High Risk',
      pivot: 67820,
      target: 64200,
      note: 'Volatility Alert'
    },
    chart: {
      timeframe: '15m',
      model: 'KINETIC-V4 LSTM',
      volumeDelta: '+142% 10D AVG',
      rsi: 62.4,
      condition: 'VOLATILITY EXPANSION',
      predictionTarget: 518.90,
      candles: [
        { time: '13:00', open: 508.8, high: 509.9, low: 508.4, close: 509.5, volume: 18000, isBullish: true },
        { time: '13:15', open: 509.5, high: 509.8, low: 508.9, close: 509.1, volume: 14000, isBullish: false },
        { time: '13:30', open: 509.1, high: 510.4, low: 509.0, close: 510.2, volume: 22000, isBullish: true },
        { time: '13:45', open: 510.2, high: 510.5, low: 509.6, close: 509.8, volume: 16000, isBullish: false },
        { time: '14:00', open: 509.8, high: 511.2, low: 509.7, close: 511.0, volume: 38000, isBullish: true },
        { time: '14:15', open: 511.0, high: 511.6, low: 510.8, close: 511.4, volume: 29000, isBullish: true },
        { time: '14:30', open: 511.4, high: 512.2, low: 511.2, close: 512.0, volume: 44000, isBullish: true },
        { time: '14:45', open: 512.0, high: 512.3, low: 511.7, close: 511.9, volume: 21000, isBullish: false },
        { time: '15:00', open: 511.9, high: 512.6, low: 511.8, close: 512.3, volume: 49000, isBullish: true },
        { time: '15:15', open: 512.3, high: 512.9, low: 512.2, close: 512.4, volume: 56000, isBullish: true },
      ]
    }
  },
  'BTC/USD': {
    symbol: 'BTC/USD',
    name: 'Bitcoin / US Dollar',
    assetClass: 'CRYPTO',
    price: 67820,
    change24h: -2.85,
    signal: {
      type: 'BEARISH REVERSAL',
      direction: 'BEARISH',
      confidence: 84,
      entry: 67820,
      target: 64200,
      stop: 68900,
      riskReward: '1:3.35',
      status: 'ACTIVE'
    },
    secondaryWarning: {
      symbol: 'ETH/USD',
      warning: 'LIQUIDITY DRY-UP',
      riskLevel: 'High Risk',
      pivot: 3450,
      target: 3200,
      note: 'Derivatives Open Interest Divergence'
    },
    chart: {
      timeframe: '15m',
      model: 'TRANSFORMER-FLOW-v2',
      volumeDelta: '+88% 10D AVG',
      rsi: 38.6,
      condition: 'DISTRIBUTION CYCLE',
      predictionTarget: 64200,
      candles: [
        { time: '13:00', open: 68400, high: 68650, low: 68200, close: 68500, volume: 420, isBullish: true },
        { time: '13:15', open: 68500, high: 68700, low: 68350, close: 68380, volume: 580, isBullish: false },
        { time: '13:30', open: 68380, high: 68450, low: 68100, close: 68150, volume: 640, isBullish: false },
        { time: '13:45', open: 68150, high: 68300, low: 68050, close: 68200, volume: 390, isBullish: true },
        { time: '14:00', open: 68200, high: 68250, low: 67900, close: 67950, volume: 820, isBullish: false },
        { time: '14:15', open: 67950, high: 68050, low: 67800, close: 67840, volume: 910, isBullish: false },
        { time: '14:30', open: 67840, high: 68000, low: 67780, close: 67920, volume: 510, isBullish: true },
        { time: '14:45', open: 67920, high: 67980, low: 67750, close: 67800, volume: 730, isBullish: false },
        { time: '15:00', open: 67800, high: 67900, low: 67700, close: 67760, volume: 880, isBullish: false },
        { time: '15:15', open: 67760, high: 67890, low: 67720, close: 67820, volume: 1040, isBullish: true },
      ]
    }
  },
  NVDA: {
    symbol: 'NVDA',
    name: 'NVIDIA Corp',
    assetClass: 'EQUITY',
    price: 128.60,
    change24h: 3.42,
    signal: {
      type: 'BULLISH CONTINUATION',
      direction: 'BULLISH',
      confidence: 91,
      entry: 128.60,
      target: 135.40,
      stop: 125.80,
      riskReward: '1:2.42',
      status: 'ACTIVE'
    },
    secondaryWarning: {
      symbol: 'AMD',
      warning: 'CORRELATED MOMENTUM',
      riskLevel: 'Low Risk',
      pivot: 168.0,
      target: 174.5,
      note: 'Semiconductor Breadth'
    },
    chart: {
      timeframe: '15m',
      model: 'CONV-MOMENTUM-X',
      volumeDelta: '+195% 10D AVG',
      rsi: 68.2,
      condition: 'INSTITUTIONAL ACCUMULATION',
      predictionTarget: 135.40,
      candles: [
        { time: '13:00', open: 125.2, high: 125.9, low: 125.0, close: 125.7, volume: 82000, isBullish: true },
        { time: '13:15', open: 125.7, high: 126.3, low: 125.6, close: 126.2, volume: 94000, isBullish: true },
        { time: '13:30', open: 126.2, high: 126.8, low: 126.1, close: 126.6, volume: 110000, isBullish: true },
        { time: '13:45', open: 126.6, high: 127.1, low: 126.4, close: 126.9, volume: 85000, isBullish: true },
        { time: '14:00', open: 126.9, high: 127.4, low: 126.7, close: 127.2, volume: 125000, isBullish: true },
        { time: '14:15', open: 127.2, high: 127.9, low: 127.1, close: 127.8, volume: 140000, isBullish: true },
        { time: '14:30', open: 127.8, high: 128.3, low: 127.6, close: 128.1, volume: 160000, isBullish: true },
        { time: '14:45', open: 128.1, high: 128.4, low: 127.9, close: 128.0, volume: 98000, isBullish: false },
        { time: '15:00', open: 128.0, high: 128.7, low: 127.9, close: 128.5, volume: 175000, isBullish: true },
        { time: '15:15', open: 128.5, high: 128.9, low: 128.3, close: 128.6, volume: 190000, isBullish: true },
      ]
    }
  },
  TSLA: {
    symbol: 'TSLA',
    name: 'Tesla Inc',
    assetClass: 'EQUITY',
    price: 218.40,
    change24h: 0.85,
    signal: {
      type: 'CONSOLIDATION SQUEEZE',
      direction: 'BULLISH',
      confidence: 81,
      entry: 218.40,
      target: 226.50,
      stop: 214.20,
      riskReward: '1:1.93',
      status: 'ACTIVE'
    },
    secondaryWarning: {
      symbol: 'RIVN',
      warning: 'SECTOR COMPRESSION',
      riskLevel: 'Medium Risk',
      pivot: 12.8,
      target: 11.4,
      note: 'Auto Margin Pressure'
    },
    chart: {
      timeframe: '15m',
      model: 'KINETIC-V4 LSTM',
      volumeDelta: '+112% 10D AVG',
      rsi: 54.1,
      condition: 'BOLLINGER BAND PINCH',
      predictionTarget: 226.50,
      candles: [
        { time: '13:00', open: 217.1, high: 217.8, low: 216.8, close: 217.5, volume: 45000, isBullish: true },
        { time: '13:15', open: 217.5, high: 217.9, low: 217.2, close: 217.4, volume: 38000, isBullish: false },
        { time: '13:30', open: 217.4, high: 218.1, low: 217.3, close: 218.0, volume: 42000, isBullish: true },
        { time: '13:45', open: 218.0, high: 218.3, low: 217.7, close: 217.9, volume: 35000, isBullish: false },
        { time: '14:00', open: 217.9, high: 218.5, low: 217.8, close: 218.2, volume: 51000, isBullish: true },
        { time: '14:15', open: 218.2, high: 218.6, low: 218.0, close: 218.1, volume: 48000, isBullish: false },
        { time: '14:30', open: 218.1, high: 218.7, low: 218.0, close: 218.5, volume: 59000, isBullish: true },
        { time: '14:45', open: 218.5, high: 218.8, low: 218.2, close: 218.3, volume: 41000, isBullish: false },
        { time: '15:00', open: 218.3, high: 218.9, low: 218.2, close: 218.7, volume: 63000, isBullish: true },
        { time: '15:15', open: 218.7, high: 219.0, low: 218.3, close: 218.4, volume: 68000, isBullish: false },
      ]
    }
  },
  'EUR/USD': {
    symbol: 'EUR/USD',
    name: 'Euro / US Dollar',
    assetClass: 'FOREX',
    price: 1.0845,
    change24h: 0.18,
    signal: {
      type: 'BULLISH BREAKOUT',
      direction: 'BULLISH',
      confidence: 86,
      entry: 1.0845,
      target: 1.0910,
      stop: 1.0815,
      riskReward: '1:2.16',
      status: 'ACTIVE'
    },
    secondaryWarning: {
      symbol: 'DXY',
      warning: 'DOLLAR WEAKNESS',
      riskLevel: 'Medium Risk',
      pivot: 104.2,
      target: 103.5,
      note: 'Macro Treasury Yield Drop'
    },
    chart: {
      timeframe: '15m',
      model: 'TRANSFORMER-FLOW-v2',
      volumeDelta: '+76% 10D AVG',
      rsi: 58.7,
      condition: 'TREND ACCELERATION',
      predictionTarget: 1.0910,
      candles: [
        { time: '13:00', open: 1.0820, high: 1.0828, low: 1.0818, close: 1.0825, volume: 12000, isBullish: true },
        { time: '13:15', open: 1.0825, high: 1.0831, low: 1.0824, close: 1.0829, volume: 14000, isBullish: true },
        { time: '13:30', open: 1.0829, high: 1.0833, low: 1.0827, close: 1.0830, volume: 11000, isBullish: true },
        { time: '13:45', open: 1.0830, high: 1.0835, low: 1.0828, close: 1.0834, volume: 13000, isBullish: true },
        { time: '14:00', open: 1.0834, high: 1.0838, low: 1.0832, close: 1.0836, volume: 16000, isBullish: true },
        { time: '14:15', open: 1.0836, high: 1.0840, low: 1.0834, close: 1.0839, volume: 15000, isBullish: true },
        { time: '14:30', open: 1.0839, high: 1.0843, low: 1.0838, close: 1.0842, volume: 18000, isBullish: true },
        { time: '14:45', open: 1.0842, high: 1.0845, low: 1.0840, close: 1.0841, volume: 12000, isBullish: false },
        { time: '15:00', open: 1.0841, high: 1.0848, low: 1.0840, close: 1.0846, volume: 21000, isBullish: true },
        { time: '15:15', open: 1.0846, high: 1.0849, low: 1.0843, close: 1.0845, volume: 22000, isBullish: false },
      ]
    }
  }
};

export const HISTORICAL_LEDGER: LedgerItem[] = [
  {
    id: 'SIG-8921',
    date: 'Today, 14:15',
    symbol: 'SPY',
    assetName: 'S&P 500 ETF',
    action: 'LONG',
    entryPrice: 512.40,
    exitPrice: 518.90,
    targetPrice: 518.90,
    stopLoss: 509.80,
    pnlPercent: +1.27,
    rMultiple: 2.50,
    outcome: 'OPEN',
    confidence: 87,
    model: 'KINETIC-V4 LSTM',
    executionMs: 11.2
  },
  {
    id: 'SIG-8919',
    date: 'Yesterday, 15:40',
    symbol: 'NVDA',
    assetName: 'NVIDIA Corp',
    action: 'LONG',
    entryPrice: 123.80,
    exitPrice: 128.40,
    targetPrice: 128.20,
    stopLoss: 121.90,
    pnlPercent: +3.71,
    rMultiple: 2.42,
    outcome: 'WIN',
    confidence: 93,
    model: 'CONV-MOMENTUM-X',
    executionMs: 9.8
  },
  {
    id: 'SIG-8916',
    date: 'Yesterday, 11:20',
    symbol: 'BTC/USD',
    assetName: 'Bitcoin',
    action: 'SHORT',
    entryPrice: 69150,
    exitPrice: 66900,
    targetPrice: 67100,
    stopLoss: 70100,
    pnlPercent: +3.25,
    rMultiple: 2.37,
    outcome: 'WIN',
    confidence: 88,
    model: 'TRANSFORMER-FLOW-v2',
    executionMs: 12.1
  },
  {
    id: 'SIG-8912',
    date: 'Oct 8, 14:05',
    symbol: 'TSLA',
    assetName: 'Tesla Inc',
    action: 'LONG',
    entryPrice: 212.10,
    exitPrice: 217.80,
    targetPrice: 218.00,
    stopLoss: 209.50,
    pnlPercent: +2.69,
    rMultiple: 2.19,
    outcome: 'WIN',
    confidence: 84,
    model: 'KINETIC-V4 LSTM',
    executionMs: 10.4
  },
  {
    id: 'SIG-8908',
    date: 'Oct 8, 09:45',
    symbol: 'SPY',
    assetName: 'S&P 500 ETF',
    action: 'SHORT',
    entryPrice: 514.20,
    exitPrice: 515.30,
    targetPrice: 509.80,
    stopLoss: 515.30,
    pnlPercent: -0.21,
    rMultiple: -1.00,
    outcome: 'LOSS',
    confidence: 79,
    model: 'KINETIC-V4 LSTM',
    executionMs: 11.8
  },
  {
    id: 'SIG-8905',
    date: 'Oct 7, 13:20',
    symbol: 'EUR/USD',
    assetName: 'Euro / US Dollar',
    action: 'LONG',
    entryPrice: 1.0790,
    exitPrice: 1.0852,
    targetPrice: 1.0850,
    stopLoss: 1.0765,
    pnlPercent: +0.57,
    rMultiple: 2.48,
    outcome: 'WIN',
    confidence: 90,
    model: 'TRANSFORMER-FLOW-v2',
    executionMs: 8.9
  },
  {
    id: 'SIG-8901',
    date: 'Oct 7, 10:15',
    symbol: 'NVDA',
    assetName: 'NVIDIA Corp',
    action: 'LONG',
    entryPrice: 119.40,
    exitPrice: 123.60,
    targetPrice: 123.50,
    stopLoss: 117.80,
    pnlPercent: +3.52,
    rMultiple: 2.62,
    outcome: 'WIN',
    confidence: 89,
    model: 'CONV-MOMENTUM-X',
    executionMs: 10.2
  },
  {
    id: 'SIG-8897',
    date: 'Oct 6, 14:50',
    symbol: 'BTC/USD',
    assetName: 'Bitcoin',
    action: 'LONG',
    entryPrice: 65400,
    exitPrice: 68100,
    targetPrice: 68000,
    stopLoss: 64200,
    pnlPercent: +4.13,
    rMultiple: 2.25,
    outcome: 'WIN',
    confidence: 91,
    model: 'TRANSFORMER-FLOW-v2',
    executionMs: 11.4
  },
  {
    id: 'SIG-8893',
    date: 'Oct 5, 11:35',
    symbol: 'SPY',
    assetName: 'S&P 500 ETF',
    action: 'LONG',
    entryPrice: 508.30,
    exitPrice: 513.10,
    targetPrice: 513.00,
    stopLoss: 506.40,
    pnlPercent: +0.94,
    rMultiple: 2.52,
    outcome: 'WIN',
    confidence: 86,
    model: 'KINETIC-V4 LSTM',
    executionMs: 10.7
  },
  {
    id: 'SIG-8889',
    date: 'Oct 4, 15:10',
    symbol: 'TSLA',
    assetName: 'Tesla Inc',
    action: 'SHORT',
    entryPrice: 224.50,
    exitPrice: 226.30,
    targetPrice: 218.00,
    stopLoss: 226.30,
    pnlPercent: -0.80,
    rMultiple: -1.00,
    outcome: 'LOSS',
    confidence: 76,
    model: 'KINETIC-V4 LSTM',
    executionMs: 12.4
  }
];

export const FAQ_DATA: FaqItem[] = [
  {
    id: 'faq-1',
    question: 'How accurate are the predictions?',
    answer: 'The AI uses historical backtesting and real-time data to provide the highest probability direction, though no tool can guarantee results. Our 30-day trailing signal verification records an 84.6% win-rate on high-confidence triggers (conf >= 80%).'
  },
  {
    id: 'faq-2',
    question: 'Does this trade for me?',
    answer: 'No, this is a decision-support tool designed to give you better data so you can make your own trades. It acts as an institutional-grade co-pilot that verifies order setups and calculates stop-loss and risk/reward parameters.'
  },
  {
    id: 'faq-3',
    question: 'What markets are covered?',
    answer: 'We currently provide signals for major stocks (S&P 500, Nasdaq 100), high-throughput crypto pairs (BTC, ETH, SOL), forex pairs (EUR/USD, GBP/USD, USD/JPY), and high-volume index commodities.'
  },
  {
    id: 'faq-4',
    question: 'Do I need technical skills?',
    answer: 'Not at all; the interface is built for regular traders, not programmers or mathematicians. All neural model scores are presented cleanly with entry targets, stop boundaries, and directional probabilities.'
  },
  {
    id: 'faq-5',
    question: 'Can I cancel my subscription?',
    answer: 'Yes, you can manage your subscription and cancel at any time through your account settings with a single click. There are zero lock-ins or hidden cancellation penalties.'
  }
];
