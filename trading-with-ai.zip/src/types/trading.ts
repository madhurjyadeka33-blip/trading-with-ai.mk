export interface TickerData {
  symbol: string;
  name: string;
  assetClass: 'ETF' | 'CRYPTO' | 'EQUITY' | 'FOREX';
  price: number;
  change24h: number;
  signal: {
    type: 'BULLISH BREAKOUT' | 'BEARISH REVERSAL' | 'BULLISH CONTINUATION' | 'CONSOLIDATION SQUEEZE';
    direction: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
    confidence: number;
    entry: number;
    target: number;
    stop: number;
    riskReward: string;
    status: 'ACTIVE' | 'PENDING' | 'TRIGGERED';
  };
  secondaryWarning?: {
    symbol: string;
    warning: string;
    riskLevel: 'High Risk' | 'Medium Risk' | 'Low Risk';
    pivot: number;
    target: number;
    note: string;
  };
  chart: {
    timeframe: '1m' | '5m' | '15m' | '1H' | '1D';
    model: string;
    volumeDelta: string;
    rsi: number;
    condition: string;
    candles: Array<{
      time: string;
      open: number;
      high: number;
      low: number;
      close: number;
      volume: number;
      isBullish: boolean;
    }>;
    predictionTarget: number;
  };
}

export interface LedgerItem {
  id: string;
  date: string;
  symbol: string;
  assetName: string;
  action: 'LONG' | 'SHORT';
  entryPrice: number;
  exitPrice: number;
  targetPrice: number;
  stopLoss: number;
  pnlPercent: number;
  rMultiple: number;
  outcome: 'WIN' | 'LOSS' | 'OPEN';
  confidence: number;
  model: string;
  executionMs: number;
}

export interface PricingPlan {
  id: 'basic' | 'pro';
  name: string;
  description: string;
  priceMonthly: number;
  priceAnnual: number;
  isPopular?: boolean;
  features: string[];
  ctaText: string;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
}
